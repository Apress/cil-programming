This ZIP file contains all of the source code for the Apress book, "CIL Programming: Under the Hood of .NET".  Each Chapter0X folder contains code from the related chapter.  The source code comes in a number of flavors:

1)  A fair amount of the code is in the form of a VS .NET solution containing either VB .NET or C# code.  If you have VS .NET installed, all you need to do is load the solution file (*.sln).  You can also compile the code with .NET's command line tools (vbc.exe for VB .NET and csc.exe for C#).

2)  If the subfolder contains a *.il file, you need to compile these files with ilasm.  All of the *.il files contain a comment line that specifies the correct ilasm command line for that file.

3)  Chapter 1 has a number of subfolders that contain code in non-MS .NET languages.  Following is a list of instructions on how to compile the code:


A)  Open the Orders project in Visual Basic 6, and compile the application.  This code should work with any version of VB 6 - I ran it with Service Pack 4 installed, but the code is basic enough that it should not be SP-specific.

B)  Open the PersonDefinition project in the Person directory, and compile the code.

C)  Take the resulting PersonDefinition.DLL and put it into the PersonImpl directory.  Create the PersonImpl.dll by running the following command:

oberon PersonImpl.mod /r:PersonDefinition.dll /dll

The Oberon for .NET compiler can be found at:

http://www.oberon.ethz.eh/oberon.net

D)  Open the Customer project, and compile.  You may need to reset the references to the PersonDefinition.dll and PersonImpl.dll assemblies.

E)  Open the CustomerOrders project, and compile.  You may need to reset the references to the PersonDefinition.dll, PersonImpl.dll, and Customer.dll assemblies along with the Orders COM server.


4)  Chapter06 contains a subfolder called SimpleCPCOde.  This is ComponentPascal code.  To compile it, run:

gpcp SimpleCPCode.cp

The Gardens Point Component Pascal compiler can be found at:

http://www2.fit.qut.edu.au/CompSci/PLAS//ComponentPascal/

5)  If you find any .mod files, this is Oberon code.  Please refer to 3.C in this file for the command to compile Oberon code - make sure you read the documentation on Oberon's compiler when you install it for compiler switch details.


If anything is unclear in these instructions, please e-mail me at jason@jasonbock.net.