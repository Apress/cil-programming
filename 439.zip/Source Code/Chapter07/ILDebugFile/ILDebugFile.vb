Option Strict On
Option Explicit On 

Imports Microsoft.VisualBasic.Constants
Imports System.Collections
Imports System.Diagnostics.SymbolStore
Imports System.IO
Imports System.Reflection
Imports System.Reflection.Emit
Imports System.Text

Public Class DebugFile
    Private Const ARG As String = "V_"
    Private Const ARG_DLM As String = ","
    Private Const BEGIN_ARGS As String = "("
    Private Const BEGIN_SCOPE As String = "{"
    Private Const CLASS_IL As String = ".class"
    Private Const CLASS_EXTENDS_IL As String = "extends"
    Private Const CLASS_IMPLEMENTS_IL As String = "implements"
    Private Const END_ARGS As String = ")"
    Private Const END_SCOPE As String = "}"
    Private Const INDENT As Integer = 3
    Private Const LBL As String = "Label"
    Private Const LBL_END As String = ":"
    Private Const METHOD_IL As String = ".method"
    Private Const SP As String = " "

    Private m_ILGen As ILGenerator
    Private m_ILWriter As TextWriter
    Private m_IndentLevel As Integer = 0
    Private m_LineCount As Integer = 0
    Private m_symDoc As ISymbolDocumentWriter
    Private m_methodParams As Hashtable

    Private Shared Function GetAttributes(ByVal AttribType As Type, ByVal AttribValue As Integer) As String
        Dim attribString As StringBuilder = New StringBuilder()

        If AttribType.IsEnum = True Then
            Dim field As FieldInfo
            For Each field In AttribType.GetFields(BindingFlags.Public Or BindingFlags.Static)
                Dim fieldValue As Integer = CInt(field.GetValue(Nothing))
                If (fieldValue And AttribValue) = fieldValue Then
                    attribString.Append(field.Name).Append(SP)
                End If
            Next
        End If

        Return LCase(attribString.ToString())
    End Function

    Public Sub New(ByVal ILFile As String, ByVal CanOverwrite As Boolean, ByVal SymDoc As ISymbolDocumentWriter)
        If SymDoc Is Nothing Then
            Throw New Exception("The symbol document writer reference cannot be null.")
        End If

        If File.Exists(ILFile) = True And CanOverwrite = False Then
            Throw New Exception("The given file exists and cannot be overwritten.")
        End If

        If CanOverwrite = True And File.Exists(ILFile) = True Then
            File.Delete(ILFile)
        End If

        m_ILWriter = New StreamWriter(ILFile, CanOverwrite)
        Me.m_symDoc = SymDoc
        Me.m_methodParams = New Hashtable()
    End Sub

    Public Sub AddLocals(ByVal NewLocals() As LocalBuilder, Optional ByVal InitLocals As Boolean = True)

    End Sub

    Public Sub AddOpCode(ByVal NewOpCode As OpCode)
        Me.WriteText(NewOpCode.ToString())
        Me.MarkSequencePoint(NewOpCode.ToString().Length)
    End Sub

    Public Sub AddOpCode(ByVal NewOpCode As OpCode, ByVal TargetField As FieldInfo)
        Me.WriteText(NewOpCode.ToString() + SP + TargetField.Name)
        Me.MarkSequencePoint(NewOpCode.ToString().Length)
    End Sub

    Public Sub AddOpCode(ByVal NewOpCode As OpCode, ByVal TargetLabel As Label)
        Me.WriteText(NewOpCode.ToString() + SP + LBL + TargetLabel.GetHashCode().ToString)
        Me.MarkSequencePoint(NewOpCode.ToString().Length)
    End Sub

    Public Sub AddOpCode(ByVal NewOpCode As OpCode, ByVal Value As String)
        Me.WriteText(NewOpCode.ToString() + SP + Value)
        Me.MarkSequencePoint(NewOpCode.ToString().Length)
    End Sub

    Public Sub AddOpCode(ByVal NewOpCode As OpCode, ByVal InvokedMethod As MethodBase)
        Dim opBuilder As StringBuilder = New StringBuilder()

        opBuilder.Append(NewOpCode.ToString()).Append(SP)

        Dim argTypes() As Type

        Try
            If Not InvokedMethod.GetParameters() Is Nothing And InvokedMethod.GetParameters().Length > 0 Then
                ReDim argTypes(InvokedMethod.GetParameters().Length - 1)

                Dim argC As Integer = 0
                Dim paramInfo As ParameterInfo
                For Each paramInfo In InvokedMethod.GetParameters()
                    argTypes(argC) = paramInfo.ParameterType
                Next
            End If
        Catch e As Exception
            '  See if the method arg info is in the hashtable.
            Dim sig As String = Me.GetMethodSignature(InvokedMethod)
            If Me.m_methodParams.ContainsKey(sig) = True Then
                argTypes = CType(Me.m_methodParams.Item(sig), Type())
            End If
        End Try

        opBuilder.Append(Me.GetMethodArgInfo(InvokedMethod.Name, argTypes))

        Me.WriteText(opBuilder.ToString())
        Me.MarkSequencePoint(opBuilder.ToString().Length)
    End Sub

    Public Sub AddOpCode(ByVal NewOpCode As OpCode, ByVal TargetType As Type)
        Me.WriteText(NewOpCode.ToString() + SP + TargetType.FullName)
        Me.MarkSequencePoint(NewOpCode.ToString().Length)
    End Sub

    Public Sub AddOpCode(ByVal NewOpCode As OpCode, ByVal Value As ValueType)
        Me.WriteText(NewOpCode.ToString() + SP + Value.ToString())
        Me.MarkSequencePoint(NewOpCode.ToString().Length)
    End Sub

    Private Sub AddMethodArgs(ByVal TargetMethod As MethodBase, ByVal MethodArgs() As Type)
        Dim sig As String = Me.GetMethodSignature(TargetMethod)

        If Me.m_methodParams.ContainsKey(sig) = False Then
            Me.m_methodParams.Add(sig, MethodArgs)
        End If
    End Sub

    Public Sub EndScope(Optional ByVal IsMethod As Boolean = False)
        m_IndentLevel = m_IndentLevel - 1
        Me.WriteText(END_SCOPE)

        If IsMethod = True Then
            Me.MarkSequencePoint(END_SCOPE.Length)
        End If

        Me.WriteText(vbNullString)
    End Sub

    Private Function GetAttributeString(ByVal Attrib As MethodBase) As String
        Dim sb As StringBuilder = New StringBuilder()

        With Attrib
            '  Is is public, private, nested...?
            If .IsPublic Then
                sb.Append("public").Append(" ")
            ElseIf .IsFamily Then
                sb.Append("family").Append(" ")
            ElseIf .IsFamilyAndAssembly Then
                sb.Append("famandassembly").Append(" ")
            ElseIf .IsFamilyOrAssembly Then
                sb.Append("familyorassembly").Append(" ")
            ElseIf .IsPrivate Then
                sb.Append("private").Append(" ")
            Else
            End If

            '  Is is abstract, virtual, static?
            If .IsAbstract Then
                sb.Append("abstract").Append(" ")
            End If
            If .IsVirtual Then
                sb.Append("virtual").Append(" ")
            End If
            If .IsStatic Then
                sb.Append("static").Append(" ")
            End If
            If .IsConstructor Then
                sb.Append("constructor").Append(" ")
            End If

            '  Is it hidebysig, rtspecialname, etc.?
            If .IsHideBySig Then
                sb.Append("hidebysig").Append(" ")
            End If
            If .IsSpecialName Then
                sb.Append("specialname").Append(" ")
            End If

            If (.CallingConvention And CallingConventions.VarArgs) > 0 Then
                sb.Append("vararg").Append(" ")
            End If
            If (.CallingConvention And CallingConventions.ExplicitThis) > 0 Then
                sb.Append("explicitthis").Append(" ")
            End If
            If (.CallingConvention And CallingConventions.HasThis) > 0 Then
                sb.Append("hasthis").Append(" ")
            End If
            If (.CallingConvention And CallingConventions.Standard) > 0 Then
                sb.Append("standard").Append(" ")
            End If
        End With
        Return sb.ToString()
    End Function

    Private Function GetAttributeString(ByVal Attrib As Type) As String
        Dim sb As StringBuilder = New StringBuilder()

        With Attrib
            '  Is is public, private, nested...?
            If .IsPublic Then
                sb.Append("public").Append(" ")
            ElseIf .IsNestedAssembly Then
                sb.Append("nestedassembly").Append(" ")
            ElseIf .IsNestedFamANDAssem Then
                sb.Append("nestedfamandassembly").Append(" ")
            ElseIf .IsNestedFamily Then
                sb.Append("nestedfamily").Append(" ")
            ElseIf .IsNestedFamORAssem Then
                sb.Append("nestedfamorassembly").Append(" ")
            ElseIf .IsNestedPrivate Then
                sb.Append("nestedprivate").Append(" ")
            Else
                sb.Append("private").Append(" ")
            End If

            '  Is is abstract, sealed?
            If .IsAbstract And Not .IsInterface Then
                sb.Append("abstract").Append(" ")
            ElseIf .IsSealed Then
                sb.Append("sealed").Append(" ")
            End If

            '  Is it auto, ansi, or unicode?
            If .IsAutoClass Then
                sb.Append("auto").Append(" ")
            ElseIf .IsAnsiClass Then
                sb.Append("ansi").Append(" ")
            ElseIf .IsUnicodeClass Then
                sb.Append("unicode").Append(" ")
            Else
            End If

            '  Is it serializable?
            If .IsSerializable Then
                sb.Append("serializable").Append(" ")
            End If

            '  Is it class, interface, value type (or enum)?
            If .IsClass Then
                sb.Append("class").Append(" ")
            ElseIf .IsInterface Then
                sb.Append("interface").Append(" ")
            ElseIf .IsEnum Then
                sb.Append("enum").Append(" ")
            Else
                sb.Append("valuetype").Append(" ")
            End If
        End With

        Return sb.ToString()
    End Function

    Private Function GetIndent() As String
        Return New String(SP.Chars(0), INDENT * m_IndentLevel)
    End Function

    Private Function GetMethodArgInfo(ByVal TargetMethodName As String, ByVal MethodArgs() As Type) As String
        Dim MethodInfo As StringBuilder = New StringBuilder()

        MethodInfo.Append(TargetMethodName)
        MethodInfo.Append(BEGIN_ARGS)

        Dim argType As Type
        Dim argC As Integer = 0

        If Not MethodArgs Is Nothing AndAlso MethodArgs.Length > 0 Then
            For Each argType In MethodArgs
                argC = argC + 1
                MethodInfo.Append(argType.FullName).Append(SP).Append(ARG).Append(argC.ToString())
                If (argC < MethodArgs.Length) Then
                    MethodInfo.Append(ARG_DLM).Append(SP)
                End If
            Next
        End If

        MethodInfo.Append(END_ARGS)

        Return MethodInfo.ToString()
    End Function

    Private Function GetMethodSignature(ByVal TargetMethod As MethodBase) As String
        Dim sig As String

        If TypeOf TargetMethod Is MethodBuilder Then
            sig = CType(TargetMethod, MethodBuilder).Signature
        Else
            sig = CType(TargetMethod, ConstructorBuilder).Signature
        End If

        Return sig
    End Function

    Public Sub MarkLabel(ByVal LabelLocation As Label)
        Me.WriteText(LBL + LabelLocation.GetHashCode().ToString + LBL_END)
    End Sub

    Private Sub MarkSequencePoint(ByVal ILCodeLength As Integer)
        Dim curIndent As Integer = (INDENT * m_IndentLevel) + 1
        Me.m_ILGen.MarkSequencePoint(Me.m_symDoc, Me.m_LineCount, curIndent, _
            Me.m_LineCount, curIndent + ILCodeLength)
    End Sub

    Public Sub Save()
        m_ILWriter.Close()
    End Sub

    Public Sub StartMethod(ByVal NewMethod As MethodBase, ByVal MethodArgs() As Type, ByVal ILGen As ILGenerator)
        m_ILGen = ILGen

        Dim MethodInfo As StringBuilder = New StringBuilder()

        MethodInfo.Append(METHOD_IL).Append(SP)
        MethodInfo.Append(GetAttributeString(NewMethod))

        If TypeOf NewMethod Is MethodInfo Then
            MethodInfo.Append(CType(NewMethod, MethodInfo).ReturnType.Name).Append(SP)
        End If

        MethodInfo.Append(Me.GetMethodArgInfo(NewMethod.Name, MethodArgs))

        Me.AddMethodArgs(NewMethod, MethodArgs)

        Me.WriteText(MethodInfo.ToString())
        Me.WriteText(BEGIN_SCOPE)
        m_IndentLevel = m_IndentLevel + 1
    End Sub

    Public Sub StartType(ByVal NewType As TypeBuilder)
        Dim TypeInfo As StringBuilder = New StringBuilder()

        TypeInfo.Append(CLASS_IL).Append(SP)
        TypeInfo.Append(GetAttributeString(NewType))

        TypeInfo.Append(NewType.FullName).Append(SP)
        TypeInfo.Append(CLASS_EXTENDS_IL).Append(SP).Append(NewType.BaseType().FullName).Append(SP)

        Dim typeInterface As Type
        If Not NewType.GetInterfaces() Is Nothing Then
            For Each typeInterface In NewType.GetInterfaces()
                TypeInfo.Append(CLASS_IMPLEMENTS_IL).Append(SP).Append(typeInterface.FullName).Append(SP)
            Next
        End If

        Me.WriteText(TypeInfo.ToString())
        Me.WriteText(BEGIN_SCOPE)
        m_IndentLevel = m_IndentLevel + 1
    End Sub

    Private Sub WriteText(ByVal TextData As String)
        m_ILWriter.WriteLine(GetIndent() + TextData)
        m_LineCount = m_LineCount + 1
    End Sub
End Class
