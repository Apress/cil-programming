Option Strict On

Imports System.Reflection
Imports System.Reflection.Emit
Imports System.Security.Permissions

<Assembly: ReflectionPermissionAttribute(SecurityAction.RequestMinimum, _
    ReflectionEmit:=True)> 

Public Interface ICustomer
    Property FirstName() As String
    Property LastName() As String
    Property Age() As Integer
    Function IsAdult() As Boolean
End Interface

Public Class StaticImplCustomer
    Implements ICustomer

    Private m_FirstName As String
    Private m_LastName As String
    Private m_Age As Integer

    Public Sub New()
        MyBase.new()
    End Sub

    Public Sub New(ByVal FirstName As String, ByVal LastName As String)
        Me.m_FirstName = FirstName
        Me.m_LastName = LastName

        Dim rnd As Random = New Random()

        Me.m_Age = rnd.Next(100)
    End Sub

    Public Function IsAdult() As Boolean Implements ICustomer.IsAdult
        Dim retVal As Boolean = False

        If m_Age >= 18 Then
            retVal = True
        End If

        Return retVal
    End Function

    Public Property FirstName() As String Implements ICustomer.FirstName
        Get
            Return Me.m_FirstName
        End Get
        Set(ByVal Value As String)
            Me.m_FirstName = Value
        End Set
    End Property

    Public Property LastName() As String Implements ICustomer.LastName
        Get
            Return Me.m_LastName
        End Get
        Set(ByVal Value As String)
            Me.m_LastName = Value
        End Set
    End Property

    Public Property Age() As Integer Implements ICustomer.Age
        Get
            Return Me.m_Age
        End Get
        Set(ByVal Value As Integer)
            Me.m_Age = Value
        End Set
    End Property
End Class

Public Class DynamicImplCustomer

    Private Const CUST_ASM As String = "DynamicCustomer"
    Private Const CUST_MODULE As String = "DynamicCustomerModule"
    Private Const CUST_FIRST_NAME_FIELD As String = "m_FirstName"
    Private Const CUST_LAST_NAME_FIELD As String = "m_LastName"
    Private Const CUST_AGE_FIELD As String = "m_Age"

    Private Shared m_FirstNameField As FieldInfo
    Private Shared m_LastNameField As FieldInfo
    Private Shared m_AgeField As FieldInfo

    Public Shared Function Create(ByVal FirstName As String, _
        ByVal LastName As String) As ICustomer

        Dim DynCustAsm As AssemblyBuilder
        Dim DynCustAsmModule As ModuleBuilder
        Dim DynCustAsmName As AssemblyName

        DynCustAsmName = New AssemblyName()

        With DynCustAsmName
            .Name = CUST_ASM
            .Version = New Version(1, 0, 0, 0)
        End With

        Dim uniqueCustName As String = Guid.NewGuid().ToString()

        DynCustAsm = AppDomain.CurrentDomain.DefineDynamicAssembly( _
            DynCustAsmName, AssemblyBuilderAccess.Save)
        DynCustAsmModule = DynCustAsm.DefineDynamicModule(CUST_MODULE + ".dll")

        Dim newCustInterfaces(0) As Type
        newCustInterfaces(0) = GetType(ICustomer)

        Dim newCust As TypeBuilder
        newCust = DynCustAsmModule.DefineType("Customer" + uniqueCustName, _
            TypeAttributes.Class Or TypeAttributes.Public, _
            GetType(System.Object), newCustInterfaces)

        BuildFields(newCust)
        BuildConstructor(newCust, FirstName, LastName)
        BuildProperties(newCust)
        BuildIsAdultMethod(newCust)

        Dim newCustType As Type = newCust.CreateType()
        DynCustAsm.Save(CUST_MODULE + ".dll")

        '  Create a new instance.
        Return CType(DynCustAsm.CreateInstance("Customer" + uniqueCustName), ICustomer)
    End Function

    Private Shared Sub BuildFields(ByVal NewCust As TypeBuilder)
        '  Add the fields to store
        '  the first and last names
        '  along with the age.
        m_FirstNameField = NewCust.DefineField(CUST_FIRST_NAME_FIELD, _
            GetType(System.String), FieldAttributes.Private)
        m_LastNameField = NewCust.DefineField(CUST_LAST_NAME_FIELD, _
            GetType(System.String), FieldAttributes.Private)
        m_AgeField = NewCust.DefineField(CUST_AGE_FIELD, _
            GetType(System.Int32), FieldAttributes.Private)
    End Sub

    Private Shared Sub BuildProperties(ByVal NewCust As TypeBuilder)
        '  Implement all of the getters and setters.
        Dim firstNameGetIL As ILGenerator
        Dim firstNameGet As MethodBuilder
        Dim firstNameSetIL As ILGenerator
        Dim firstNameSet As MethodBuilder
        Dim lastNameGetIL As ILGenerator
        Dim lastNameGet As MethodBuilder
        Dim lastNameSetIL As ILGenerator
        Dim lastNameSet As MethodBuilder
        Dim ageGetIL As ILGenerator
        Dim ageGet As MethodBuilder
        Dim ageSetIL As ILGenerator
        Dim ageSet As MethodBuilder
        Dim parentMethod As MethodInfo
        Dim propertyArgs(0) As Type

        '  "get_FirstName()"
        firstNameGet = NewCust.DefineMethod("get_FirstName", _
            MethodAttributes.HideBySig Or _
            MethodAttributes.NewSlot Or MethodAttributes.Virtual Or _
            MethodAttributes.Private, GetType(System.String), System.Type.EmptyTypes)

        parentMethod = GetType(ICustomer).GetMethod("get_FirstName")
        NewCust.DefineMethodOverride(firstNameGet, parentMethod)

        firstNameGetIL = firstNameGet.GetILGenerator()

        firstNameGetIL.Emit(OpCodes.Ldarg_0)
        firstNameGetIL.Emit(OpCodes.Ldfld, m_FirstNameField)
        firstNameGetIL.Emit(OpCodes.Ret)

        '  "set_FirstName()"
        propertyArgs(0) = GetType(System.String)
        firstNameSet = NewCust.DefineMethod("set_FirstName", _
            MethodAttributes.HideBySig Or _
            MethodAttributes.NewSlot Or MethodAttributes.Virtual Or _
            MethodAttributes.Private, Nothing, propertyArgs)

        parentMethod = GetType(ICustomer).GetMethod("set_FirstName")
        NewCust.DefineMethodOverride(firstNameSet, parentMethod)

        firstNameSetIL = firstNameSet.GetILGenerator()

        firstNameSetIL.Emit(OpCodes.Ldarg_0)
        firstNameSetIL.Emit(OpCodes.Ldarg_1)
        firstNameSetIL.Emit(OpCodes.Stfld, m_FirstNameField)
        firstNameSetIL.Emit(OpCodes.Ret)

        '  "get_LastName()"
        lastNameGet = NewCust.DefineMethod("get_LastName", _
            MethodAttributes.HideBySig Or _
            MethodAttributes.NewSlot Or MethodAttributes.Virtual Or _
            MethodAttributes.Private, GetType(System.String), System.Type.EmptyTypes)

        parentMethod = GetType(ICustomer).GetMethod("get_LastName")
        NewCust.DefineMethodOverride(lastNameGet, parentMethod)

        lastNameGetIL = lastNameGet.GetILGenerator()

        lastNameGetIL.Emit(OpCodes.Ldarg_0)
        lastNameGetIL.Emit(OpCodes.Ldfld, m_LastNameField)
        lastNameGetIL.Emit(OpCodes.Ret)

        '  "set_LastName()"
        propertyArgs(0) = GetType(System.String)
        lastNameSet = NewCust.DefineMethod("set_LastName", _
            MethodAttributes.HideBySig Or _
            MethodAttributes.NewSlot Or MethodAttributes.Virtual Or _
            MethodAttributes.Private, Nothing, propertyArgs)

        parentMethod = GetType(ICustomer).GetMethod("set_LastName")
        NewCust.DefineMethodOverride(lastNameSet, parentMethod)

        lastNameSetIL = lastNameSet.GetILGenerator()

        lastNameSetIL.Emit(OpCodes.Ldarg_0)
        lastNameSetIL.Emit(OpCodes.Ldarg_1)
        lastNameSetIL.Emit(OpCodes.Stfld, m_LastNameField)
        lastNameSetIL.Emit(OpCodes.Ret)

        '  "get_Age()"
        ageGet = NewCust.DefineMethod("get_Age", _
            MethodAttributes.HideBySig Or _
            MethodAttributes.NewSlot Or MethodAttributes.Virtual Or _
            MethodAttributes.Private, GetType(System.Int32), System.Type.EmptyTypes)

        parentMethod = GetType(ICustomer).GetMethod("get_Age")
        NewCust.DefineMethodOverride(ageGet, parentMethod)

        ageGetIL = ageGet.GetILGenerator()

        ageGetIL.Emit(OpCodes.Ldarg_0)
        ageGetIL.Emit(OpCodes.Ldfld, m_AgeField)
        ageGetIL.Emit(OpCodes.Ret)

        '  "set_Age()"
        propertyArgs(0) = GetType(System.Int32)
        ageSet = NewCust.DefineMethod("set_Age", _
            MethodAttributes.HideBySig Or _
            MethodAttributes.NewSlot Or MethodAttributes.Virtual Or _
            MethodAttributes.Private, Nothing, propertyArgs)

        parentMethod = GetType(ICustomer).GetMethod("set_Age")
        NewCust.DefineMethodOverride(ageSet, parentMethod)

        ageSetIL = ageSet.GetILGenerator()

        ageSetIL.Emit(OpCodes.Ldarg_0)
        ageSetIL.Emit(OpCodes.Ldarg_1)
        ageSetIL.Emit(OpCodes.Stfld, m_AgeField)
        ageSetIL.Emit(OpCodes.Ret)
    End Sub

    Private Shared Sub BuildConstructor(ByVal NewCust As TypeBuilder, ByVal FirstName As String, _
        ByVal LastName As String)

        Dim custCtor As ConstructorBuilder
        Dim custIL As ILGenerator
        Dim rndAge As LocalBuilder

        custCtor = NewCust.DefineConstructor(MethodAttributes.Public Or _
                MethodAttributes.SpecialName Or MethodAttributes.RTSpecialName Or _
                MethodAttributes.HideBySig, CallingConventions.Standard, Nothing)

        custIL = custCtor.GetILGenerator()
        rndAge = custIL.DeclareLocal(GetType(System.Random))

        '  Call the base constructor.
        custIL.Emit(OpCodes.Ldarg_0)
        custIL.Emit(OpCodes.Call, _
            GetType(System.Object).GetConstructor(System.Type.EmptyTypes))

        '  Set the private field values here.
        '  First Name.
        custIL.Emit(OpCodes.Ldarg_0)
        custIL.Emit(OpCodes.Ldstr, FirstName)
        custIL.Emit(OpCodes.Stfld, m_FirstNameField)
        '  Last Name
        custIL.Emit(OpCodes.Ldarg_0)
        custIL.Emit(OpCodes.Ldstr, LastName)
        custIL.Emit(OpCodes.Stfld, m_LastNameField)
        '  Age - this will be random between 0 and 100.
        custIL.Emit(OpCodes.Newobj, GetType(System.Random).GetConstructor(System.Type.EmptyTypes))
        custIL.Emit(OpCodes.Stloc_0)
        custIL.Emit(OpCodes.Ldarg_0)
        custIL.Emit(OpCodes.Ldloc_0)
        custIL.Emit(OpCodes.Ldc_I4, 100)
        Dim rndArgTypes(0) As Type
        rndArgTypes(0) = GetType(System.Int32)
        custIL.Emit(OpCodes.Callvirt, _
            GetType(System.Random).GetMethod("Next", rndArgTypes))
        custIL.Emit(OpCodes.Stfld, m_AgeField)
        custIL.Emit(OpCodes.Ret)
    End Sub

    Private Shared Sub BuildIsAdultMethod(ByVal NewCust As TypeBuilder)
        Dim isAdultMethod As MethodBuilder
        Dim parentMethod As MethodInfo
        Dim isAdultIL As ILGenerator
        Dim isTrue As Label
        Dim finishMethod As Label
        Dim ILretVal As LocalBuilder
        Dim exceptionLabel As Label

        parentMethod = GetType(ICustomer).GetMethod("IsAdult")
        isAdultMethod = NewCust.DefineMethod("IsAdultImpl", MethodAttributes.HideBySig Or _
            MethodAttributes.NewSlot Or MethodAttributes.Virtual Or _
            MethodAttributes.Public, GetType(System.Boolean), Nothing)

        NewCust.DefineMethodOverride(isAdultMethod, parentMethod)

        isAdultIL = isAdultMethod.GetILGenerator()
        ILretVal = isAdultIL.DeclareLocal(GetType(System.Boolean))

        '  Initialize the local to false.
        isAdultIL.Emit(OpCodes.Ldc_I4_0)
        isAdultIL.Emit(OpCodes.Stloc_0)

        exceptionLabel = isAdultIL.BeginExceptionBlock()
        '  Check to see if the CUST_AGE_FIELD is equal
        '  to or greater than 18.
        isAdultIL.Emit(OpCodes.Ldarg_0)
        isAdultIL.Emit(OpCodes.Ldfld, m_AgeField)
        isAdultIL.Emit(OpCodes.Ldc_I4_S, 18)
        isTrue = isAdultIL.DefineLabel()
        finishMethod = isAdultIL.DefineLabel()
        isAdultIL.Emit(OpCodes.Bge, isTrue)
        '  This customer is not an adult.
        isAdultIL.Emit(OpCodes.Br, finishMethod)
        '  This customer is an adult.
        isAdultIL.MarkLabel(isTrue)
        isAdultIL.Emit(OpCodes.Ldc_I4_1)
        isAdultIL.Emit(OpCodes.Stloc_0)
        isAdultIL.MarkLabel(finishMethod)
        isAdultIL.BeginCatchBlock(GetType(System.Exception))
        isAdultIL.BeginFinallyBlock()
        isAdultIL.EndExceptionBlock()
        '  Push the retVal and return.  
        isAdultIL.Emit(OpCodes.Ldloc_0)
        isAdultIL.Emit(OpCodes.Ret)
    End Sub
End Class
