Imports DynamicCustomer

Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents btnCreate As System.Windows.Forms.Button
    Friend WithEvents lblAge As System.Windows.Forms.Label
    Friend WithEvents lblIsAdult As System.Windows.Forms.Label
    Friend WithEvents txtAge As System.Windows.Forms.TextBox
    Friend WithEvents txtIsAdult As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.lblAge = New System.Windows.Forms.Label()
        Me.lblIsAdult = New System.Windows.Forms.Label()
        Me.txtAge = New System.Windows.Forms.TextBox()
        Me.txtIsAdult = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblFirstName
        '
        Me.lblFirstName.Location = New System.Drawing.Point(8, 8)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(72, 16)
        Me.lblFirstName.TabIndex = 0
        Me.lblFirstName.Text = "&First Name:"
        '
        'lblLastName
        '
        Me.lblLastName.Location = New System.Drawing.Point(8, 32)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(72, 16)
        Me.lblLastName.TabIndex = 1
        Me.lblLastName.Text = "&Last Name:"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(80, 8)
        Me.txtFirstName.MaxLength = 50
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(112, 20)
        Me.txtFirstName.TabIndex = 2
        Me.txtFirstName.Text = ""
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(80, 32)
        Me.txtLastName.MaxLength = 50
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(112, 20)
        Me.txtLastName.TabIndex = 3
        Me.txtLastName.Text = ""
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(8, 64)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(72, 24)
        Me.btnCreate.TabIndex = 4
        Me.btnCreate.Text = "&Create"
        '
        'lblAge
        '
        Me.lblAge.Location = New System.Drawing.Point(8, 96)
        Me.lblAge.Name = "lblAge"
        Me.lblAge.Size = New System.Drawing.Size(72, 16)
        Me.lblAge.TabIndex = 5
        Me.lblAge.Text = "Age:"
        '
        'lblIsAdult
        '
        Me.lblIsAdult.Location = New System.Drawing.Point(8, 120)
        Me.lblIsAdult.Name = "lblIsAdult"
        Me.lblIsAdult.Size = New System.Drawing.Size(72, 16)
        Me.lblIsAdult.TabIndex = 6
        Me.lblIsAdult.Text = "Is Adult?"
        '
        'txtAge
        '
        Me.txtAge.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.txtAge.Location = New System.Drawing.Point(80, 96)
        Me.txtAge.MaxLength = 50
        Me.txtAge.Name = "txtAge"
        Me.txtAge.ReadOnly = True
        Me.txtAge.Size = New System.Drawing.Size(112, 20)
        Me.txtAge.TabIndex = 7
        Me.txtAge.Text = ""
        '
        'txtIsAdult
        '
        Me.txtIsAdult.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.txtIsAdult.Location = New System.Drawing.Point(80, 120)
        Me.txtIsAdult.MaxLength = 50
        Me.txtIsAdult.Name = "txtIsAdult"
        Me.txtIsAdult.ReadOnly = True
        Me.txtIsAdult.Size = New System.Drawing.Size(112, 20)
        Me.txtIsAdult.TabIndex = 8
        Me.txtIsAdult.Text = ""
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(202, 151)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtIsAdult, Me.txtAge, Me.lblIsAdult, Me.lblAge, Me.btnCreate, Me.txtLastName, Me.txtFirstName, Me.lblLastName, Me.lblFirstName})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dynamic Customer Test"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreate.Click
        Try
            Me.txtAge.Text = vbNullString
            Me.txtIsAdult.Text = vbNullString

            Dim aCust As ICustomer

            aCust = DynamicImplCustomer.Create(Me.txtFirstName.Text, _
                Me.txtLastName.Text)

            Me.txtAge.Text = aCust.Age.ToString()
            Me.txtIsAdult.Text = aCust.IsAdult().ToString()
        Catch Ex As Exception
            MessageBox.Show(Ex.ToString())
        End Try
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
