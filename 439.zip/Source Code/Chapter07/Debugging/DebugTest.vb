Option Strict On

Imports System.Diagnostics.SymbolStore
Imports System.IO
Imports System.Reflection
Imports System.Reflection.Emit
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Runtime.Serialization.Formatters.Soap
Imports System.Security.Permissions
Imports ILDebugFile

<Assembly: ReflectionPermissionAttribute(SecurityAction.RequestMinimum, _
    ReflectionEmit:=True)> 

Public Interface IReturn
    Function ReturnTheDouble(ByVal TheDouble As Double) As Double
End Interface

Public Class DynamicReturn

    Private Const RETURN_ASM_NAME As String = "ReturnAssembly"
    Private Const RETURN_MODULE_NAME As String = "ReturnModule"
    Private Const IL_FILE As String = "c:\returnimpl.il"
    Private Shared m_symDoc As ISymbolDocumentWriter
    Private Shared m_ilFile As DebugFile

    Public Shared Function Create() As IReturn

        Dim ReturnAsm As AssemblyBuilder
        Dim ReturnAsmModule As ModuleBuilder
        Dim ReturnAsmName As AssemblyName

        ReturnAsmName = New AssemblyName()

        With ReturnAsmName
            .Name = RETURN_ASM_NAME
            .Version = New Version(1, 0, 0, 0)
        End With

        ReturnAsm = AppDomain.CurrentDomain.DefineDynamicAssembly( _
            ReturnAsmName, AssemblyBuilderAccess.Save)

        'ReturnAsm = AppDomain.CurrentDomain.DefineDynamicAssembly( _
        '    ReturnAsmName, AssemblyBuilderAccess.Run)

        Dim debugAttribs(1) As Type
        debugAttribs(0) = GetType(System.Boolean)
        debugAttribs(1) = GetType(System.Boolean)
        Dim dbgAttrib As Type
        dbgAttrib = GetType(System.Diagnostics.DebuggableAttribute)
        Dim dbgCtor As ConstructorInfo
        dbgCtor = dbgAttrib.GetConstructor(debugAttribs)
        Dim dbgAttribBuilder As CustomAttributeBuilder
        Dim dbgArgs(1) As Object
        dbgArgs(0) = True
        dbgArgs(1) = True
        dbgAttribBuilder = New CustomAttributeBuilder(dbgCtor, dbgArgs)
        ReturnAsm.SetCustomAttribute(dbgAttribBuilder)

        ReturnAsmModule = ReturnAsm.DefineDynamicModule(RETURN_MODULE_NAME, _
            RETURN_MODULE_NAME + ".dll", True)

        'ReturnAsmModule = ReturnAsm.DefineDynamicModule(RETURN_MODULE_NAME, True)

        m_symDoc = ReturnAsmModule.DefineDocument(IL_FILE, _
            SymLanguageType.ILAssembly, SymLanguageVendor.Microsoft, SymDocumentType.Text)

        m_ilFile = New DebugFile(IL_FILE, True, m_symDoc)

        Dim returnInterface(0) As Type
        returnInterface(0) = GetType(IReturn)

        Dim newReturn As TypeBuilder
        newReturn = ReturnAsmModule.DefineType("ReturnImpl", _
            TypeAttributes.Class Or TypeAttributes.Public, _
            GetType(System.Object), returnInterface)

        m_ilFile.StartType(newReturn)
        BuildConstructor(newReturn)
        BuildReturnTheDoubleMethod(newReturn)

        Dim newReturnType As Type = newReturn.CreateType()

        m_ilFile.EndScope()
        ReturnAsm.Save(RETURN_ASM_NAME + ".dll")
        m_ilFile.Save()

        '  Create a new instance.
        'Return CType(ReturnAsm.CreateInstance("ReturnImpl"), IReturn)

        Dim newAsm As [Assembly] = [Assembly].LoadFrom(RETURN_ASM_NAME + ".dll")
        Return CType(newAsm.CreateInstance("ReturnImpl"), IReturn)
    End Function

    Private Shared Sub BuildConstructor(ByVal NewReturn As TypeBuilder)

        Dim returnCtor As ConstructorBuilder
        Dim returnIL As ILGenerator

        returnCtor = NewReturn.DefineConstructor(MethodAttributes.Public Or _
                MethodAttributes.SpecialName Or MethodAttributes.RTSpecialName Or _
                MethodAttributes.HideBySig, CallingConventions.Standard, Nothing)
        returnIL = returnCtor.GetILGenerator()

        m_ilFile.StartMethod(returnCtor, Nothing, returnIL)

        returnIL.BeginScope()
        '  Call the base constructor.
        m_ilFile.AddOpCode(OpCodes.Ldarg_0)
        returnIL.Emit(OpCodes.Ldarg_0)

        m_ilFile.AddOpCode(OpCodes.Call, GetType(System.Object).GetConstructor(System.Type.EmptyTypes))
        returnIL.Emit(OpCodes.Call, _
            GetType(System.Object).GetConstructor(System.Type.EmptyTypes))

        m_ilFile.AddOpCode(OpCodes.Ret)
        returnIL.Emit(OpCodes.Ret)

        m_ilFile.EndScope(True)
        returnIL.EndScope()
    End Sub

    Private Shared Sub BuildReturnTheDoubleMethod(ByVal NewReturn As TypeBuilder)
        Dim returnTheDoubleMethod As MethodBuilder
        Dim parentMethod As MethodInfo
        Dim rtdIL As ILGenerator
        Dim rtdArgTypes(0) As Type
        rtdArgTypes(0) = GetType(System.Double)

        parentMethod = GetType(IReturn).GetMethod("ReturnTheDouble")
        returnTheDoubleMethod = NewReturn.DefineMethod("ReturnTheDoubleImpl", _
            MethodAttributes.HideBySig Or _
            MethodAttributes.NewSlot Or MethodAttributes.Virtual Or _
            MethodAttributes.Public, GetType(System.Double), rtdArgTypes)

        NewReturn.DefineMethodOverride(returnTheDoubleMethod, parentMethod)

        Dim uselessInt As LocalBuilder

        rtdIL = returnTheDoubleMethod.GetILGenerator()
        m_ilFile.StartMethod(returnTheDoubleMethod, rtdArgTypes, rtdIL)

        rtdIL.BeginScope()

        uselessInt = rtdIL.DeclareLocal(GetType(System.Int32))
        uselessInt.SetLocalSymInfo("uselessInt")
        '  Purposely cause an error.
        m_ilFile.AddOpCode(OpCodes.Ldc_I4_3)
        rtdIL.Emit(OpCodes.Ldc_I4_3)

        m_ilFile.AddOpCode(OpCodes.Ldc_I4_0)
        rtdIL.Emit(OpCodes.Ldc_I4_0)

        m_ilFile.AddOpCode(OpCodes.Div)
        rtdIL.Emit(OpCodes.Div)

        m_ilFile.AddOpCode(OpCodes.Pop)
        rtdIL.Emit(OpCodes.Pop)

        m_ilFile.AddOpCode(OpCodes.Ldarg_1)
        rtdIL.Emit(OpCodes.Ldarg_1)

        m_ilFile.AddOpCode(OpCodes.Ret)
        rtdIL.Emit(OpCodes.Ret)

        m_ilFile.EndScope(True)
        rtdIL.EndScope()
    End Sub
End Class
