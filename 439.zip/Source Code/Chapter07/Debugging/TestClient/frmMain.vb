Imports Debugging
Imports System.Reflection

Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
Friend WithEvents lblDoubleValue As System.Windows.Forms.Label
Friend WithEvents txtDoubleValue As System.Windows.Forms.TextBox
Friend WithEvents btnCreate As System.Windows.Forms.Button
Friend WithEvents btnUseExisting As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblDoubleValue = New System.Windows.Forms.Label()
        Me.txtDoubleValue = New System.Windows.Forms.TextBox()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnUseExisting = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblDoubleValue
        '
        Me.lblDoubleValue.Location = New System.Drawing.Point(8, 8)
        Me.lblDoubleValue.Name = "lblDoubleValue"
        Me.lblDoubleValue.Size = New System.Drawing.Size(96, 16)
        Me.lblDoubleValue.TabIndex = 0
        Me.lblDoubleValue.Text = "&Double Value:"
        '
        'txtDoubleValue
        '
        Me.txtDoubleValue.Location = New System.Drawing.Point(88, 8)
        Me.txtDoubleValue.Name = "txtDoubleValue"
        Me.txtDoubleValue.Size = New System.Drawing.Size(192, 20)
        Me.txtDoubleValue.TabIndex = 1
        Me.txtDoubleValue.Text = ""
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(8, 40)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(120, 24)
        Me.btnCreate.TabIndex = 2
        Me.btnCreate.Text = "&Create"
        '
        'btnUseExisting
        '
        Me.btnUseExisting.Location = New System.Drawing.Point(8, 72)
        Me.btnUseExisting.Name = "btnUseExisting"
        Me.btnUseExisting.Size = New System.Drawing.Size(120, 24)
        Me.btnUseExisting.TabIndex = 3
        Me.btnUseExisting.Text = "&Use Existing"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnUseExisting, Me.btnCreate, Me.txtDoubleValue, Me.lblDoubleValue})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Return Double Test"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreate.Click
        Dim ret As IReturn
        ret = DynamicReturn.Create()
        MessageBox.Show(ret.ReturnTheDouble(CDbl(Me.txtDoubleValue.Text)))
    End Sub

    Private Sub btnUseExisting_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUseExisting.Click
        Dim ret As IReturn
        ret = CType([Assembly].LoadFrom("ReturnModule.dll").CreateInstance("ReturnImpl"), IReturn)
        MessageBox.Show(ret.ReturnTheDouble(CDbl(Me.txtDoubleValue.Text)))
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
