Option Strict On
Option Explicit On 

Imports System
Imports System.Reflection
Imports System.Reflection.Emit

Public Class BTB

    Public Shared Sub Main()
        Dim an As AssemblyName = New AssemblyName()
        an.Name = "NewAssembly"

        Dim ab As AssemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly( _
            an, AssemblyBuilderAccess.Save)

        Dim mb As ModuleBuilder = ab.DefineDynamicModule("NewAssembly", "NewAssembly.exe", True)
        Dim tb As TypeBuilder = mb.DefineType("RunThis")
        Dim mthb As MethodBuilder = tb.DefineMethod("Go", MethodAttributes.Static Or _
            MethodAttributes.Public, Nothing, System.Type.EmptyTypes)

        Dim multByTwo As MethodBuilder = _
            MultiplyByTwoMethod(tb)

        Dim mImpl As ILGenerator = mthb.GetILGenerator()
        Dim mLoc As LocalBuilder = mImpl.DeclareLocal(GetType(System.Int32))
        mImpl.EmitWriteLine("I'm here.")
        '  Call with an argument.
        mImpl.EmitWriteLine("Multiply 5 by 2.")
        mImpl.Emit(OpCodes.Ldc_I4_5)
        mImpl.Emit(OpCodes.Stloc_0)
        mImpl.Emit(OpCodes.Ldloc_0)
        mImpl.Emit(OpCodes.Call, multByTwo)
        Dim writeLineTypes() As Type = {GetType(System.Int32)}
        mImpl.Emit(OpCodes.Call, GetType(System.Console).GetMethod("WriteLine", writeLineTypes))

        '  Call with the "default".
        mImpl.EmitWriteLine("Multiply default by 2.")
        mImpl.Emit(OpCodes.Ldc_I4_S, 25)
        mImpl.Emit(OpCodes.Call, multByTwo)
        mImpl.Emit(OpCodes.Call, GetType(System.Console).GetMethod("WriteLine", writeLineTypes))
        mImpl.Emit(OpCodes.Ret)

        AddCLSComplianceAttribute(ab)
        AddLoaderOptimizationAttribute(mthb)

        tb.CreateType()
        ab.SetEntryPoint(mthb, PEFileKinds.ConsoleApplication)

        ab.Save("NewAssembly.exe")

        AppDomain.CurrentDomain.ExecuteAssembly("NewAssembly.exe")
    End Sub

    Private Shared Function MultiplyByTwoMethod(ByRef TargetType As TypeBuilder) As MethodBuilder
        Dim argTypes() As Type = {Type.GetType("System.Int32")}

        Dim elseMethod As MethodBuilder = TargetType.DefineMethod("MultiplyByTwo", _
            MethodAttributes.Static Or MethodAttributes.Public, _
            GetType(System.Int32), argTypes)

        Dim symAttrib() As Byte = {1, 0, 1, 0, 0}

        elseMethod.SetSymCustomAttribute("SomeAttribute", symAttrib)

        Dim paramInfo As ParameterBuilder = elseMethod.DefineParameter(1, _
            ParameterAttributes.Optional Or ParameterAttributes.HasDefault, _
            "ANumber")

        paramInfo.SetConstant(CInt(25))
        Dim elseIL As ILGenerator = elseMethod.GetILGenerator()
        elseIL.Emit(OpCodes.Ldarg_0)
        elseIL.Emit(OpCodes.Ldc_I4_2)
        elseIL.Emit(OpCodes.Mul)
        elseIL.Emit(OpCodes.Ret)

        Return elseMethod
    End Function

    Private Shared Sub AddCLSComplianceAttribute(ByRef TargetAssembly As AssemblyBuilder)
        Dim ctorArgs(0) As Type
        ctorArgs(0) = GetType(System.Boolean)

        Dim clsAttrib As Type
        clsAttrib = GetType(System.CLSCompliantAttribute)

        Dim clsAttribCtor As ConstructorInfo
        clsAttribCtor = clsAttrib.GetConstructor(ctorArgs)

        Dim clsAttribBuilder As CustomAttributeBuilder

        Dim clsArgs(0) As Object
        clsArgs(0) = False

        clsAttribBuilder = New CustomAttributeBuilder(clsAttribCtor, clsArgs)
        TargetAssembly.SetCustomAttribute(clsAttribBuilder)
    End Sub

    Private Shared Sub AddLoaderOptimizationAttribute(ByRef TargetEntryPoint As MethodBuilder)
        Dim ctorArgs(0) As Type
        ctorArgs(0) = GetType(System.Byte)

        Dim loaderAttrib As Type
        loaderAttrib = GetType(System.LoaderOptimizationAttribute)

        Dim loaderAttribCtor As ConstructorInfo
        loaderAttribCtor = loaderAttrib.GetConstructor(ctorArgs)

        Dim attribInfo() As Byte = {1, 0, 1, 0, 0}

        TargetEntryPoint.SetCustomAttribute(loaderAttribCtor, attribInfo)
    End Sub
End Class