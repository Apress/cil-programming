Public Class VBConsumer
    Public Sub CallCSharpClass()
        Dim X As EasyCSharpClass = New EasyCSharpClass()
        x.AMethod()
    End Sub
End Class