public class EasyCSharpClass
{
    private int m_AMemberVariable;
    public void AMethod() 
    {
        int x = 0;
        x++;
        x += CalledMethod();
    }
    private int CalledMethod() 
    {
        return 4;
    }
}

