Option Strict On
Option Explicit On 

Imports CustomerDefinition
Imports Orders

Public Class frmMain
    Inherits System.Windows.Forms.Form

    Private m_Customer As ICustomer
    Private m_Order As Order

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblCustomerName As System.Windows.Forms.Label
    Friend WithEvents txtCustomerNameValue As System.Windows.Forms.TextBox
    Friend WithEvents lblCustomerID As System.Windows.Forms.Label
    Friend WithEvents txtCustomerWalletValue As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCustomerUpdate As System.Windows.Forms.Button
    Friend WithEvents txtOrderPriceValue As System.Windows.Forms.TextBox
    Friend WithEvents lblOrderPrice As System.Windows.Forms.Label
    Friend WithEvents txtOrderNameValue As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnAddOrderItem As System.Windows.Forms.Button
    Friend WithEvents lblCurrentTotal As System.Windows.Forms.Label
    Friend WithEvents lblCurrentTotalValue As System.Windows.Forms.Label
    Friend WithEvents btnRemoveOrderItems As System.Windows.Forms.Button
    Friend WithEvents txtCustomerIDValue As System.Windows.Forms.TextBox
Friend WithEvents lstOrderItems As System.Windows.Forms.ListView
Friend WithEvents chrOrderName As System.Windows.Forms.ColumnHeader
Friend WithEvents chrOrderPrice As System.Windows.Forms.ColumnHeader
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.lblCustomerName = New System.Windows.Forms.Label()
Me.txtCustomerNameValue = New System.Windows.Forms.TextBox()
Me.txtCustomerIDValue = New System.Windows.Forms.TextBox()
Me.lblCustomerID = New System.Windows.Forms.Label()
Me.txtCustomerWalletValue = New System.Windows.Forms.TextBox()
Me.Label1 = New System.Windows.Forms.Label()
Me.btnCustomerUpdate = New System.Windows.Forms.Button()
Me.txtOrderPriceValue = New System.Windows.Forms.TextBox()
Me.lblOrderPrice = New System.Windows.Forms.Label()
Me.txtOrderNameValue = New System.Windows.Forms.TextBox()
Me.Label3 = New System.Windows.Forms.Label()
Me.btnAddOrderItem = New System.Windows.Forms.Button()
Me.lstOrderItems = New System.Windows.Forms.ListView()
Me.lblCurrentTotal = New System.Windows.Forms.Label()
Me.lblCurrentTotalValue = New System.Windows.Forms.Label()
Me.btnRemoveOrderItems = New System.Windows.Forms.Button()
Me.chrOrderName = New System.Windows.Forms.ColumnHeader()
Me.chrOrderPrice = New System.Windows.Forms.ColumnHeader()
Me.SuspendLayout()
'
'lblCustomerName
'
Me.lblCustomerName.Location = New System.Drawing.Point(8, 8)
Me.lblCustomerName.Name = "lblCustomerName"
Me.lblCustomerName.Size = New System.Drawing.Size(112, 16)
Me.lblCustomerName.TabIndex = 0
Me.lblCustomerName.Text = "Customer Name:"
Me.lblCustomerName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
'
'txtCustomerNameValue
'
Me.txtCustomerNameValue.Location = New System.Drawing.Point(120, 8)
Me.txtCustomerNameValue.MaxLength = 50
Me.txtCustomerNameValue.Name = "txtCustomerNameValue"
Me.txtCustomerNameValue.Size = New System.Drawing.Size(160, 20)
Me.txtCustomerNameValue.TabIndex = 1
Me.txtCustomerNameValue.Text = ""
'
'txtCustomerIDValue
'
Me.txtCustomerIDValue.Location = New System.Drawing.Point(120, 32)
Me.txtCustomerIDValue.MaxLength = 50
Me.txtCustomerIDValue.Name = "txtCustomerIDValue"
Me.txtCustomerIDValue.Size = New System.Drawing.Size(160, 20)
Me.txtCustomerIDValue.TabIndex = 3
Me.txtCustomerIDValue.Text = ""
'
'lblCustomerID
'
Me.lblCustomerID.Location = New System.Drawing.Point(8, 32)
Me.lblCustomerID.Name = "lblCustomerID"
Me.lblCustomerID.Size = New System.Drawing.Size(112, 16)
Me.lblCustomerID.TabIndex = 2
Me.lblCustomerID.Text = "Customer ID:"
Me.lblCustomerID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
'
'txtCustomerWalletValue
'
Me.txtCustomerWalletValue.Location = New System.Drawing.Point(120, 56)
Me.txtCustomerWalletValue.MaxLength = 50
Me.txtCustomerWalletValue.Name = "txtCustomerWalletValue"
Me.txtCustomerWalletValue.Size = New System.Drawing.Size(160, 20)
Me.txtCustomerWalletValue.TabIndex = 5
Me.txtCustomerWalletValue.Text = ""
'
'Label1
'
Me.Label1.Location = New System.Drawing.Point(8, 56)
Me.Label1.Name = "Label1"
Me.Label1.Size = New System.Drawing.Size(112, 16)
Me.Label1.TabIndex = 4
Me.Label1.Text = "Customer Wallet:"
Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
'
'btnCustomerUpdate
'
Me.btnCustomerUpdate.Location = New System.Drawing.Point(120, 80)
Me.btnCustomerUpdate.Name = "btnCustomerUpdate"
Me.btnCustomerUpdate.Size = New System.Drawing.Size(160, 24)
Me.btnCustomerUpdate.TabIndex = 6
Me.btnCustomerUpdate.Text = "Update Customer"
'
'txtOrderPriceValue
'
Me.txtOrderPriceValue.Location = New System.Drawing.Point(120, 136)
Me.txtOrderPriceValue.MaxLength = 50
Me.txtOrderPriceValue.Name = "txtOrderPriceValue"
Me.txtOrderPriceValue.Size = New System.Drawing.Size(160, 20)
Me.txtOrderPriceValue.TabIndex = 10
Me.txtOrderPriceValue.Text = ""
'
'lblOrderPrice
'
Me.lblOrderPrice.Location = New System.Drawing.Point(8, 136)
Me.lblOrderPrice.Name = "lblOrderPrice"
Me.lblOrderPrice.Size = New System.Drawing.Size(112, 16)
Me.lblOrderPrice.TabIndex = 9
Me.lblOrderPrice.Text = "Order Item Price:"
Me.lblOrderPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight
'
'txtOrderNameValue
'
Me.txtOrderNameValue.Location = New System.Drawing.Point(120, 112)
Me.txtOrderNameValue.MaxLength = 50
Me.txtOrderNameValue.Name = "txtOrderNameValue"
Me.txtOrderNameValue.Size = New System.Drawing.Size(160, 20)
Me.txtOrderNameValue.TabIndex = 8
Me.txtOrderNameValue.Text = ""
'
'Label3
'
Me.Label3.Location = New System.Drawing.Point(8, 112)
Me.Label3.Name = "Label3"
Me.Label3.Size = New System.Drawing.Size(112, 16)
Me.Label3.TabIndex = 7
Me.Label3.Text = "Order Item Name:"
Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
'
'btnAddOrderItem
'
Me.btnAddOrderItem.Location = New System.Drawing.Point(120, 160)
Me.btnAddOrderItem.Name = "btnAddOrderItem"
Me.btnAddOrderItem.Size = New System.Drawing.Size(160, 24)
Me.btnAddOrderItem.TabIndex = 11
Me.btnAddOrderItem.Text = "Add Order Item"
'
'lstOrderItems
'
Me.lstOrderItems.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chrOrderName, Me.chrOrderPrice})
Me.lstOrderItems.Location = New System.Drawing.Point(8, 192)
Me.lstOrderItems.Name = "lstOrderItems"
Me.lstOrderItems.Size = New System.Drawing.Size(272, 104)
Me.lstOrderItems.TabIndex = 12
Me.lstOrderItems.View = System.Windows.Forms.View.Details
'
'lblCurrentTotal
'
Me.lblCurrentTotal.Location = New System.Drawing.Point(80, 304)
Me.lblCurrentTotal.Name = "lblCurrentTotal"
Me.lblCurrentTotal.Size = New System.Drawing.Size(80, 16)
Me.lblCurrentTotal.TabIndex = 13
Me.lblCurrentTotal.Text = "Current Total:"
Me.lblCurrentTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
'
'lblCurrentTotalValue
'
Me.lblCurrentTotalValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.lblCurrentTotalValue.Location = New System.Drawing.Point(168, 304)
Me.lblCurrentTotalValue.Name = "lblCurrentTotalValue"
Me.lblCurrentTotalValue.Size = New System.Drawing.Size(112, 16)
Me.lblCurrentTotalValue.TabIndex = 14
Me.lblCurrentTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight
'
'btnRemoveOrderItems
'
Me.btnRemoveOrderItems.Location = New System.Drawing.Point(120, 328)
Me.btnRemoveOrderItems.Name = "btnRemoveOrderItems"
Me.btnRemoveOrderItems.Size = New System.Drawing.Size(160, 24)
Me.btnRemoveOrderItems.TabIndex = 15
Me.btnRemoveOrderItems.Text = "Remove Order Item(s)"
'
'chrOrderName
'
Me.chrOrderName.Text = "Name"
Me.chrOrderName.Width = 144
'
'chrOrderPrice
'
Me.chrOrderPrice.Text = "Price"
Me.chrOrderPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
'
'frmMain
'
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.ClientSize = New System.Drawing.Size(292, 357)
Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnRemoveOrderItems, Me.lblCurrentTotalValue, Me.lblCurrentTotal, Me.lstOrderItems, Me.btnAddOrderItem, Me.txtOrderPriceValue, Me.lblOrderPrice, Me.txtOrderNameValue, Me.Label3, Me.btnCustomerUpdate, Me.txtCustomerWalletValue, Me.Label1, Me.txtCustomerIDValue, Me.lblCustomerID, Me.txtCustomerNameValue, Me.lblCustomerName})
Me.MaximizeBox = False
Me.MinimizeBox = False
Me.Name = "frmMain"
Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
Me.Text = "Customer Order"
Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnCustomerUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCustomerUpdate.Click
        UpdateCustomer(Me.txtCustomerNameValue.Text, _
            CInt(Me.txtCustomerIDValue.Text), _
            CDbl(Me.txtCustomerWalletValue.Text))
    End Sub

    Private Sub UpdateCustomer(ByVal Name As String, ByVal ID As Integer, ByVal Wallet As Double)
        If Me.m_Customer Is Nothing Then
            Me.m_Customer = New Customer(Name, ID, Wallet)
        Else
            Me.m_Customer.Name = Name
            Me.m_Customer.ID = ID
            Me.m_Customer.Wallet = Wallet
        End If
    End Sub

    Private Sub btnAddOrderItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddOrderItem.Click
        AddOrderItem(Me.txtOrderNameValue.Text, _
            CDbl(Me.txtOrderPriceValue.Text))
    End Sub

    Private Sub AddOrderItem(ByVal Name As String, ByVal Price As Double)
        If Me.m_Customer Is Nothing Then
            MessageBox.Show("You have not defined the customer yet.")
        Else
            Dim bAdd As Boolean = True

            If Me.m_Order Is Nothing Then
                Me.m_Order = New Order()
            Else
                Dim possibleTotal As Double = Me.m_Order.TotalPrice() + Price
                If Me.m_Customer.Wallet < possibleTotal Then
                    bAdd = False
                    MessageBox.Show("The total price would be " + possibleTotal.ToString() + _
                        ", but you only have " + Me.m_Customer.Wallet.ToString())
                End If
            End If

            If True = bAdd Then
                Dim orderKey As Guid = Guid.NewGuid()
                Dim anItem As OrderItem = New OrderItem()
                anItem.Name = Name
                anItem.Price = Price
                Me.m_Order.Add(anItem, orderKey.ToString())

                Dim lvi As ListViewItem = New ListViewItem(Name)
                lvi.Tag = orderKey.ToString()
                lvi.SubItems.Add(Price.ToString())
                Me.lstOrderItems.Items.Add(lvi)
                Me.lblCurrentTotalValue.Text = Me.m_Order.TotalPrice().ToString()
            End If

        End If
    End Sub

    Private Sub btnRemoveOrderItems_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveOrderItems.Click
        RemoveOrderItems()
    End Sub

    Private Sub RemoveOrderItems()
        If 0 < Me.lstOrderItems.SelectedItems.Count Then
            Dim listItem As ListViewItem
            For Each listItem In Me.lstOrderItems.SelectedItems
                Me.m_Order.Remove(listItem.Tag)
                Me.lstOrderItems.Items.Remove(listItem)
            Next
            Me.lblCurrentTotalValue.Text = Me.m_Order.TotalPrice().ToString()
        End If
    End Sub
End Class