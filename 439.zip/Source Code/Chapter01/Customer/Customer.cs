using System;
using PersonDefinition;
using PersonImpl;

namespace CustomerDefinition
{
	public interface ICustomer : IPerson
	{
		double Wallet
		{
			get;
			set;
		}
	}

	public class Customer : ICustomer
	{
		private Person m_Person;
		private double m_Wallet;

		public Customer(string Name, int ID, double Wallet)
		{
			this.m_Person = new Person(Name, ID);
			this.m_Wallet = Wallet;
		}

		public string Name
		{
			get
			{
				return this.m_Person.get_Name();
			}
			set
			{
				this.m_Person.set_Name(value);
			}
		}

		public int ID
		{
			get
			{
				return this.m_Person.get_ID();
			}
			set
			{
				this.m_Person.set_ID(value);
			}
		}

		public double Wallet
		{
			get
			{
				return this.m_Wallet;
			}
			set
			{
				this.m_Wallet = value;
			}
		}
	}
}
