using System;

namespace PersonDefinition
{
	public interface IPerson
	{
		string Name
		{
			get;
			set;
		}

		int ID
		{
			get;
			set;
		}
	}
}