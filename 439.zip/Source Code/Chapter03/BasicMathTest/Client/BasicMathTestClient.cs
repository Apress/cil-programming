using System;

namespace BasicMathTestClient
{
	class TestClient
	{
		[STAThread]
		static void Main(string[] args)
		{
			BasicMath bm = new BasicMath();
			Console.WriteLine("30 + 4 = " + bm.Add(30, 4).ToString());
			Console.WriteLine("30 - 4 = " + bm.Subtract(30, 4).ToString());
			Console.WriteLine("30 * 4 = " + bm.Multiply(30, 4).ToString());
			Console.WriteLine("30 / 4 = " + bm.Divide(30, 4).ToString());
			Console.WriteLine("30 % 4 = " + bm.Mod(30, 4).ToString());
			Console.WriteLine("3 negated = " + bm.Negate(3).ToString());
			Console.WriteLine("-4 negated = " + bm.Negate(-4).ToString());
			Console.WriteLine("30.5 negated = " + bm.Negate(30.5).ToString());
			Console.WriteLine("-41.5 negated = " + bm.Negate(-41.5).ToString());

			try
			{
				Console.WriteLine("180 + 180 = " + 
					bm.AddWithOverflow(180, 180).ToString());
				Console.WriteLine("1800000000 + 1800000000 = " + 
					bm.AddWithOverflow(1800000000, 1800000000).ToString());
			}
			catch(OverflowException oe)
			{
				Console.WriteLine("AddWithOverflow(1800000000, 1800000000) failed.");
				Console.WriteLine(oe);
			}

			try
			{
				Console.WriteLine("4.5 / 1.2 = " + bm.DivideWithCheck(4.5, 1.2).ToString());
				Console.WriteLine("4.5 / 0.0 = " + bm.DivideWithCheck(4.5, 0.0).ToString());
			}
			catch(OverflowException oe)
			{
				Console.WriteLine("DivideWithCheck(4.5, 0.0) failed.");
				Console.WriteLine(oe);
			}

		}
	}
}
