using System;
using System.Text;
using VAT;

namespace VarArgTest
{
	class TestVAT
	{
		[STAThread]
		static void Main(string[] args)
		{
			VariableArgumentTest vat = new VariableArgumentTest();
			Console.WriteLine(vat.GetType().FullName);
			Console.WriteLine(vat.LotsOfArgs(__arglist(1, 2)));
			Console.WriteLine(vat.LotsOfArgs(__arglist(1, 2, "Another one")));
			Guid aGuid = Guid.NewGuid();
			Console.WriteLine(vat.LotsOfArgs(__arglist(1.2, aGuid)));
		}
	}
}
