using System;

namespace CompareTestClient
{
	class TestClient
	{
		[STAThread]
		static void Main(string[] args)
		{
			Compare c = new Compare();
			Console.WriteLine("4 = 5 is  " + c.AreEqual(4, 5));
			Console.WriteLine("4 = 4 is  " + c.AreEqual(4, 4));
			Console.WriteLine("4 > 5 is  " + c.IsXGreaterThanY(4, 5));
			Console.WriteLine("4 < 5 is  " + c.IsXLessThanY(4, 5));
		}
	}
}
