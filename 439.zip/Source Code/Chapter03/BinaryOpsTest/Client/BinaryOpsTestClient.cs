using System;

namespace BinaryOpsTestClient
{
	class TestClient
	{
		[STAThread]
		static void Main(string[] args)
		{
			BinaryOps bo = new BinaryOps();
			Console.WriteLine("4 and 6 = " + bo.And(4, 6));
			Console.WriteLine("4 or 6 = " + bo.Or(4, 6));
			Console.WriteLine("4 xor 6 = " + bo.Xor(4, 6));
			Console.WriteLine("4 complement = " + bo.Complement(4));
			Console.WriteLine("4 shift left 3 bits = " + bo.ShiftLeft(4, 3));
			Console.WriteLine("4 shift right 1 bit = " + bo.ShiftRight(4, 1));
			Console.WriteLine("-4 shift right 1 bit = " + bo.ShiftRight(-4, 1));
			Console.WriteLine("4 shift right unsigned 1 bit = " + 
				bo.ShiftRightUnsigned(4, 1));
			Console.WriteLine("-4 shift right unsigned 1 bit = " + 
				bo.ShiftRightUnsigned(-4, 1));
			
		}
	}
}
