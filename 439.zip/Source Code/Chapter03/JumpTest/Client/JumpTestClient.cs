using System;
using System.Text;

namespace JumpTestClient
{
	class JTC
	{
		[STAThread]
		static void Main(string[] args)
		{
			JumpTest jt = new JumpTest();
			Console.WriteLine("Real value:  " + jt.GoHere().ToString());
			Console.WriteLine("Via tail.:  " + jt.GoSomewhereElseViaTail().ToString());
			Console.WriteLine("Via jmp:  " + jt.GoSomewhereElseViaJmp().ToString());
		}
	}
}
