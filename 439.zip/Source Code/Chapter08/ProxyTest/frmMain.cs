using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Reflection;
using ErrorDialog;
using Proxies;

namespace ProxyTest
{
	public class UITraceHandler : InvocationHandler
	{
		private TextBox m_TBox;

		private UITraceHandler() : base() {}

		public UITraceHandler(TextBox TraceTarget)
		{
			this.m_TBox = TraceTarget;
		}

		public void BeforeMethodInvocation(MethodContextInfo CurrentMethod, 
			ref Object[] MethodArgs, ref bool CallMethod, 
			ref bool BubbleException) 
		{
			this.m_TBox.Text += CurrentMethod.MethodName + 
				" will be called\r\n";
			this.m_TBox.Text += "on type " + CurrentMethod.TypeName + "\r\n";
			this.m_TBox.Text += "from assembly " + 
				CurrentMethod.AssemblyInformation.FullName + "\r\n";
			
			foreach(object o in MethodArgs)
			{
				this.m_TBox.Text += "\tArgument:  " + o.ToString() + "\r\n";
			}

			this.m_TBox.Text += "\r\n\r\n";

			if(CurrentMethod.MethodName.Equals("Add"))
			{
				MethodArgs[0] = 33;
				MethodArgs[1] = 44;
			}
		}
		
		public void AfterMethodInvocation(MethodContextInfo CurrentMethod, 
			ref Object[] MethodArgs, 
			ref Object ReturnValue, 
			ref bool BubbleException) 
		{
			this.m_TBox.Text += CurrentMethod.MethodName + 
				" was called\r\n";
			this.m_TBox.Text += "on type " + CurrentMethod.TypeName + "\r\n";
			this.m_TBox.Text += "from assembly " + 
				CurrentMethod.AssemblyInformation.FullName + "\r\n";
			
			if(ReturnValue != null)
			{
				this.m_TBox.Text += "\tReturn value:  " + ReturnValue.ToString() + "\r\n";
			}
			else
			{
				this.m_TBox.Text += "\tNo return value.\r\n";
			}

			if(CurrentMethod.MethodName.Equals("ReflectInt"))
			{
				//  Change the return value.
				ReturnValue = (int)456789;
			}

			this.m_TBox.Text += "\r\n\r\n";
		}
		
		public void AfterMethodInvocationWithException(MethodContextInfo CurrentMethod, 
			Exception GeneratedException, 
			ref bool BubbleGeneratedException, 
			ref bool BubbleException) 
		{
			this.m_TBox.Text += CurrentMethod.MethodName + 
				" was called \r\n";
			this.m_TBox.Text += "on type " + CurrentMethod.TypeName + "\r\n";
			this.m_TBox.Text += "from assembly " + 
				CurrentMethod.AssemblyInformation.FullName + "\r\n";		
			this.m_TBox.Text += "and an exception occurred.\r\n";		
			this.m_TBox.Text += "\r\n\r\n";

			if(CurrentMethod.TypeName.Equals("ProxyTest.TestClass") &&
				CurrentMethod.MethodName.Equals("ExceptionGeneration"))
			{
				BubbleException = true;
			}
		}
	}

	public interface IMathOps
	{
		int Add(int X, int Y);
		int Subtract(int X, int Y);
	}

	public class MathOps : IMathOps
	{
		public int Add(int X, int Y)
		{
			return X + Y;
		}

		public int Subtract(int X, int Y)
		{
			return X - Y;
		}

		public virtual int Multiply(int X, int Y)
		{
			return X * Y;
		}

		public int Divide(int X, int Y)
		{
			return X / Y;
		}
	}

	public class TestClass
	{
		public virtual int ReflectInt(int AValue)
		{
			return AValue;
		}

		public void AvoidMe() {}

		public virtual void ExceptionGeneration() 
		{
			throw new Exception("Exception occurred.");
		}
	}
	
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCreate;
		private System.Windows.Forms.Button btnCreateSimple;
		private System.Windows.Forms.TabControl tabResults;
		private System.Windows.Forms.TabPage tpgResults;
		private System.Windows.Forms.TabPage tpgInspection;
		private System.Windows.Forms.TextBox txtResults;
		private System.Windows.Forms.TextBox txtTypeInspect;
		private System.Windows.Forms.Button btnPersist;
		private System.ComponentModel.Container components = null;
		private MethodInfo m_ProxyPersist = null;

		public frmMain()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnCreate = new System.Windows.Forms.Button();
			this.btnCreateSimple = new System.Windows.Forms.Button();
			this.tabResults = new System.Windows.Forms.TabControl();
			this.tpgResults = new System.Windows.Forms.TabPage();
			this.tpgInspection = new System.Windows.Forms.TabPage();
			this.txtResults = new System.Windows.Forms.TextBox();
			this.txtTypeInspect = new System.Windows.Forms.TextBox();
			this.btnPersist = new System.Windows.Forms.Button();
			this.tabResults.SuspendLayout();
			this.tpgResults.SuspendLayout();
			this.tpgInspection.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnCreate
			// 
			this.btnCreate.Location = new System.Drawing.Point(112, 8);
			this.btnCreate.Name = "btnCreate";
			this.btnCreate.Size = new System.Drawing.Size(96, 24);
			this.btnCreate.TabIndex = 1;
			this.btnCreate.Text = "&Create";
			this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
			// 
			// btnCreateSimple
			// 
			this.btnCreateSimple.Location = new System.Drawing.Point(8, 8);
			this.btnCreateSimple.Name = "btnCreateSimple";
			this.btnCreateSimple.Size = new System.Drawing.Size(96, 24);
			this.btnCreateSimple.TabIndex = 0;
			this.btnCreateSimple.Text = "Create &Simple";
			this.btnCreateSimple.Click += new System.EventHandler(this.btnCreateSimple_Click);
			// 
			// tabResults
			// 
			this.tabResults.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.tpgResults,
																					 this.tpgInspection});
			this.tabResults.Location = new System.Drawing.Point(8, 40);
			this.tabResults.Name = "tabResults";
			this.tabResults.SelectedIndex = 0;
			this.tabResults.Size = new System.Drawing.Size(568, 320);
			this.tabResults.TabIndex = 5;
			// 
			// tpgResults
			// 
			this.tpgResults.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.txtResults});
			this.tpgResults.Location = new System.Drawing.Point(4, 22);
			this.tpgResults.Name = "tpgResults";
			this.tpgResults.Size = new System.Drawing.Size(560, 294);
			this.tpgResults.TabIndex = 0;
			this.tpgResults.Text = "Results";
			// 
			// tpgInspection
			// 
			this.tpgInspection.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.txtTypeInspect});
			this.tpgInspection.Location = new System.Drawing.Point(4, 22);
			this.tpgInspection.Name = "tpgInspection";
			this.tpgInspection.Size = new System.Drawing.Size(560, 294);
			this.tpgInspection.TabIndex = 1;
			this.tpgInspection.Text = "Proxy Type Inspection";
			// 
			// txtResults
			// 
			this.txtResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtResults.Location = new System.Drawing.Point(8, 8);
			this.txtResults.Multiline = true;
			this.txtResults.Name = "txtResults";
			this.txtResults.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtResults.Size = new System.Drawing.Size(544, 280);
			this.txtResults.TabIndex = 4;
			this.txtResults.Text = "";
			// 
			// txtTypeInspect
			// 
			this.txtTypeInspect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtTypeInspect.Location = new System.Drawing.Point(8, 7);
			this.txtTypeInspect.Multiline = true;
			this.txtTypeInspect.Name = "txtTypeInspect";
			this.txtTypeInspect.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtTypeInspect.Size = new System.Drawing.Size(544, 280);
			this.txtTypeInspect.TabIndex = 6;
			this.txtTypeInspect.Text = "";
			// 
			// btnPersist
			// 
			this.btnPersist.Location = new System.Drawing.Point(216, 8);
			this.btnPersist.Name = "btnPersist";
			this.btnPersist.Size = new System.Drawing.Size(96, 24);
			this.btnPersist.TabIndex = 2;
			this.btnPersist.Text = "&Persist";
			this.btnPersist.Click += new System.EventHandler(this.btnPersist_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(584, 365);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnPersist,
																		  this.tabResults,
																		  this.btnCreateSimple,
																		  this.btnCreate});
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Proxy Test";
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.tabResults.ResumeLayout(false);
			this.tpgResults.ResumeLayout(false);
			this.tpgInspection.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void btnCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.txtResults.Text = "";

				MathOps mo = new MathOps();
				InvocationHandler[] ih = {new UITraceHandler(this.txtResults)};
				MathOps moProxy = (MathOps)Proxy.Create(mo, ih);
				InspectType(moProxy);

				int retVal = 0;

				IMathOps imo = moProxy;
				txtResults.Text += "Calling Add()...\r\n";
				retVal = imo.Add(3, 4);
				txtResults.Text += "Add(3, 4) result is " + 
					retVal + "\r\n";
				txtResults.Text += "Calling Subtract()...\r\n";
				retVal = imo.Subtract(3, 4);
				txtResults.Text += "Subtract(3, 4) result is " + 
					retVal + "\r\n";
				txtResults.Text += "Calling Multiply()...\r\n";
				retVal = moProxy.Multiply(3, 4);
				txtResults.Text += "Multiply(3, 4) result is " + 
					retVal + "\r\n";
				txtResults.Text += "Calling Divide()...\r\n";
				retVal = moProxy.Divide(3, 4);
				txtResults.Text += "Divide(3, 4) result is " + 
					retVal + "\r\n";
			}
			catch(Exception ex)
			{
				ErrorForm ef = new ErrorForm(ex);
				ef.ShowDialog(this);
			}
		}

		private void InspectType(Object Base)
		{
			Type target = Base.GetType();
			this.txtTypeInspect.Text = "";

			txtTypeInspect.Text += "Inspecting " + 
				target.FullName + " in assembly " + 
				target.Assembly.FullName + "\r\n";

			txtTypeInspect.Text += "\r\n";
			txtTypeInspect.Text += "Public Methods\r\n";

			foreach(MethodInfo mi in target.GetMethods(BindingFlags.Instance |
				BindingFlags.Public))
			{
				txtTypeInspect.Text += "Method:  " + mi.Name + "\r\n";
				txtTypeInspect.Text += "\tVirtual:  " + 
					mi.IsVirtual + "\r\n";
			}

			txtTypeInspect.Text += "\r\n";
			txtTypeInspect.Text += "Private Methods\r\n";

			foreach(MethodInfo mi in target.GetMethods(BindingFlags.Instance |
				BindingFlags.NonPublic))
			{
				txtTypeInspect.Text += "Method:  " + mi.Name + "\r\n";
				txtTypeInspect.Text += "\tVirtual:  " + 
					mi.IsVirtual + "\r\n";
			}

			txtTypeInspect.Text += "\r\n";

			foreach(Type itf in target.GetInterfaces())
			{
				txtTypeInspect.Text += "Interface:  " + itf.Name + "\r\n";

				InterfaceMapping imap = target.GetInterfaceMap(itf);
				
				for(int i = 0; i < imap.InterfaceMethods.Length; i++)
				{
					txtTypeInspect.Text += "\tInterface Method:  " + 
						imap.InterfaceMethods[i].DeclaringType + "\r\n";
					txtTypeInspect.Text += "\tTarget Method:  " + 
						imap.TargetMethods[i].Name + "\r\n";
					txtTypeInspect.Text += "\tIs Target Method Public:  " + 
						imap.TargetMethods[i].IsPublic + "\r\n";
				}
			}
		}

		private void btnCreateSimple_Click(object sender, System.EventArgs e)
		{
			try
			{
				txtResults.Text = "";

				TestClass tc = new TestClass();
				InvocationHandler[] ih = {new UITraceHandler(this.txtResults)};
				TestClass tcProxy = (TestClass)Proxy.Create(tc, ih);
				InspectType(tcProxy);
				
				txtResults.Text += "Calling ReflectInt(4)...\r\n";
				int retVal = tcProxy.ReflectInt(4);
				txtResults.Text += "ReflectInt(4) result is " + 
					retVal + "\r\n";
				txtResults.Text += "Calling AvoidMe()...\r\n";
				tcProxy.AvoidMe();
				txtResults.Text += "AvoidMe() is finished.\r\n";
				txtResults.Text += "Calling ToString()...\r\n";
				tcProxy.ToString();
				txtResults.Text += "ToString() is finished.\r\n";
				txtResults.Text += "Calling ExceptionGeneration()...\r\n";
				tcProxy.ExceptionGeneration();
				txtResults.Text += "ExceptionGeneration() is finished.\r\n";
			}
			catch(Exception ex)
			{
				ErrorForm ef = new ErrorForm(ex);
				ef.ShowDialog(this);
			}
		}

		private void btnPersist_Click(object sender, System.EventArgs e)
		{
			//  If this method is invoked,
			//  then the Persist() method was found in the Load() event.
			this.m_ProxyPersist.Invoke(null, System.Type.EmptyTypes);
		}

		private void frmMain_Load(object sender, System.EventArgs e)
		{
			//  Check to see if the Persist method exists.
			try
			{
				this.m_ProxyPersist = typeof(Proxies.Proxy).GetMethod("Persist");
				
				if(null == this.m_ProxyPersist)
				{
					//  Don't show the Persist button.
					this.btnPersist.Visible = false;
				}
			}
			catch(Exception ex)
			{

			}
		}
	}
}
