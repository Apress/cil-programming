using System;
using System.Reflection;
using System.Runtime.Remoting.Activation;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;

namespace TypeInterception
{
	public struct MethodContextInfo
	{
		private AssemblyName m_AsmName;
		private String m_MethodName;
		private String m_TypeName;

		public MethodContextInfo(AssemblyName AssemblyInformation, String TypeName, String MethodName)
		{
			this.m_AsmName = (AssemblyName)AssemblyInformation.Clone();
			this.m_MethodName = MethodName;
			this.m_TypeName = TypeName;
		}

		public AssemblyName AssemblyInformation
		{
			get
			{
				return (AssemblyName)this.m_AsmName.Clone();
			}
		}

		public String TypeName
		{
			get
			{
				return this.m_TypeName;
			}
		}

		public String MethodName
		{
			get
			{
				return this.m_MethodName;
			}
		}
	}


	public interface IMessageNotification
	{
		void Notify(MethodContextInfo MethodInformation, Exception MethodException);
		void Notify(MethodContextInfo MethodInformation, string Message);
		void Notify(MethodContextInfo MethodInformation, object[] MethodArgs);
		void Notify(MethodContextInfo MethodInformation, object[] MethodArgs, object MethodRetVal);
	}

	[AttributeUsage(AttributeTargets.Class)]
	public class TypeInterceptionAttribute : ContextAttribute
	{
		private const string ATTRIB_NAME = "TypeInterceptionAttribute";
		
		//  Set the attribute name.
		public TypeInterceptionAttribute() : base(ATTRIB_NAME) {}

		//  Add our property to the context.
		public override void GetPropertiesForNewContext(IConstructionCallMessage ctorMsg) 
		{
			ctorMsg.ContextProperties.Add(new TypeInterceptionProperty());
		}
	}

	public class TypeInterceptionProperty : IContextProperty, IContributeObjectSink
	{
		private const string PROP_NAME = "TypeInterceptionProperty";

		public TypeInterceptionProperty() : base() {}
		
		public IMessageSink GetObjectSink(MarshalByRefObject obj, IMessageSink nextSink) 
		{
			return new TypeInterceptionMessage(nextSink);
		}

		public bool IsNewContextOK(Context newCtx) 
		{
			return true;
		}

		public void Freeze(Context newContext) {}

		public string Name 
		{
			get 
			{
				return PROP_NAME;
			}
		}
	}

	public class TypeInterceptionMessage : IMessageSink
	{
		private const string MSG_NAME = "TypeInterception";
		private const string ERROR_NO_ASYNC_PROCESSING = "Asynchronous processing is not allowed.";
		
		private IMessageSink m_NextSink;
		private MethodContextInfo m_MCI;
		private IMessageNotification m_Notify;

		internal TypeInterceptionMessage(IMessageSink NextSink)
		{
			this.m_NextSink = NextSink;	
		}

		public IMessageSink NextSink 
		{
			get 
			{
				return this.m_NextSink;
			}
		}
    
		public IMessage SyncProcessMessage(IMessage msg) 
		{
			IMessage retVal = null;

			if(msg is IMethodMessage)
			{
				BeforeInvocation(msg);
				retVal = this.m_NextSink.SyncProcessMessage(msg);
				AfterInvocation(msg, retVal);
			}

			return retVal;
		}
    
		public IMessageCtrl AsyncProcessMessage(IMessage msg, IMessageSink replySink) 
		{
			throw new InvalidOperationException(ERROR_NO_ASYNC_PROCESSING);
		}
    
		public static string ContextName 
		{
			get 
			{
				return MSG_NAME;
			}
		}

		private void BeforeInvocation(IMessage msg) 
		{
			IMethodMessage targetCall = msg as IMethodMessage;
			Type targetType = Type.GetType(targetCall.TypeName);
			
			this.m_MCI = new MethodContextInfo((AssemblyName)targetType.Assembly.GetName().Clone(),
				targetType.FullName, targetCall.MethodName);

			if(null != this.m_Notify)
			{
				this.m_Notify.Notify(this.m_MCI, targetCall.Args);
			}

			targetCall.LogicalCallContext.SetData(
				TypeInterceptionMessage.ContextName, 
				this);
		}

		public void DuringInvocation(String Message)
		{
			if(null != this.m_Notify)
			{
				this.m_Notify.Notify(m_MCI, Message);
			}
		}

		public void RegisterNotify(IMessageNotification NotifyClient)
		{
			this.m_Notify = NotifyClient;
		}

		public void UnregisterNotify()
		{
			this.m_Notify = null;
		}
    
		private void AfterInvocation(IMessage msg, IMessage msgReturn)
		{    
			IMethodReturnMessage retMsg = (IMethodReturnMessage)msgReturn;

			Exception msgEx = retMsg.Exception;
			if (msgEx != null) 
			{
				if(null != this.m_Notify)
				{
					this.m_Notify.Notify(m_MCI, msgEx);
				}
			}
			else
			{
				object retVal = null;

				if (retMsg.ReturnValue.GetType() != typeof(void))
				{
					retVal = retMsg.ReturnValue;
				}

				if(null != this.m_Notify)
				{
					this.m_Notify.Notify(this.m_MCI, retMsg.Args, retVal);
				}
			}
		}	
	}
}