using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Runtime.Remoting.Messaging;
using System.Windows.Forms;
using System.Data;
using ErrorDialog;
using TypeInterception;

namespace TypeInterceptionTest
{
	[TypeInterception()]
	public class TestClass : ContextBoundObject
	{
		public TestClass() : base()
		{
		}

		public void SetUp(IMessageNotification MessageNotify)
		{
			TypeInterceptionMessage tim = 
				(TypeInterceptionMessage)CallContext.GetData(TypeInterceptionMessage.ContextName);
			tim.RegisterNotify(MessageNotify);
		}

		public virtual int ReflectInt(int AValue)
		{
			return AValue;
		}

		public void TalkToTheChannel()
		{
			TypeInterceptionMessage tim = 
				(TypeInterceptionMessage)CallContext.GetData(TypeInterceptionMessage.ContextName);
			tim.DuringInvocation("Hey!  I'm in the method!");
		}

		public void AvoidMe() {}

		public virtual void ExceptionGeneration() 
		{
			throw new Exception("Exception occurred.");
		}
	}

	public class frmMain : System.Windows.Forms.Form, IMessageNotification
	{
		private System.Windows.Forms.Button btnCreate;
		private System.Windows.Forms.TextBox txtResults;
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			InitializeComponent();
		}

		public void Notify(MethodContextInfo MethodInformation, Exception MethodException)
		{
			this.txtResults.Text += MethodInformation.MethodName + 
				" was called\r\n";
			this.txtResults.Text += "on type " + MethodInformation.TypeName + "\r\n";
			this.txtResults.Text += "from assembly " + 
				MethodInformation.AssemblyInformation.FullName + "\r\n";
			this.txtResults.Text += "and generated the following exception:  " + 
				MethodException + "\r\n";
		}

		public void Notify(MethodContextInfo MethodInformation, string Message)
		{
			this.txtResults.Text += MethodInformation.MethodName + 
				" is being called\r\n";
			this.txtResults.Text += "on type " + MethodInformation.TypeName + "\r\n";
			this.txtResults.Text += "from assembly " + 
				MethodInformation.AssemblyInformation.FullName + "\r\n";
			this.txtResults.Text += "It sent the following message:  " + 
				Message + "\r\n";
		}

		public void Notify(MethodContextInfo MethodInformation, object[] MethodArgs)
		{
			this.txtResults.Text += MethodInformation.MethodName + 
				" will be called\r\n";
			this.txtResults.Text += "on type " + MethodInformation.TypeName + "\r\n";
			this.txtResults.Text += "from assembly " + 
				MethodInformation.AssemblyInformation.FullName + "\r\n";

			foreach(object o in MethodArgs)
			{
				this.txtResults.Text += "\tArgument:  " + o.ToString() + "\r\n";
			}
		}

		public void Notify(MethodContextInfo MethodInformation, object[] MethodArgs, object MethodRetVal)
		{
			this.txtResults.Text += MethodInformation.MethodName + 
				" was called\r\n";
			this.txtResults.Text += "on type " + MethodInformation.TypeName + "\r\n";
			this.txtResults.Text += "from assembly " + 
				MethodInformation.AssemblyInformation.FullName + "\r\n";

			foreach(object o in MethodArgs)
			{
				this.txtResults.Text += "\tArgument:  " + o.ToString() + "\r\n";
			}

			if(MethodRetVal != null)
			{
				this.txtResults.Text += "\tReturn value:  " + MethodRetVal.ToString() + "\r\n";
			}
			else
			{
				this.txtResults.Text += "\tNo return value.\r\n";
			}
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnCreate = new System.Windows.Forms.Button();
			this.txtResults = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// btnCreate
			// 
			this.btnCreate.Location = new System.Drawing.Point(8, 8);
			this.btnCreate.Name = "btnCreate";
			this.btnCreate.Size = new System.Drawing.Size(128, 24);
			this.btnCreate.TabIndex = 0;
			this.btnCreate.Text = "&Create";
			this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
			// 
			// txtResults
			// 
			this.txtResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtResults.Location = new System.Drawing.Point(8, 40);
			this.txtResults.Multiline = true;
			this.txtResults.Name = "txtResults";
			this.txtResults.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtResults.Size = new System.Drawing.Size(488, 232);
			this.txtResults.TabIndex = 1;
			this.txtResults.Text = "";
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(504, 277);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtResults,
																		  this.btnCreate});
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Type Interception Test";
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void frmMain_Load(object sender, System.EventArgs e)
		{
		
		}

		private void btnCreate_Click(object sender, System.EventArgs e)
		{
			this.txtResults.Text = "";

			try
			{
				TestClass tc = new TestClass();
				tc.SetUp(this);
				txtResults.Text += "Calling ReflectInt(4)...\r\n";
				int retVal = tc.ReflectInt(4);
				txtResults.Text += "ReflectInt(4) result is " + 
					retVal + "\r\n\r\n";
				txtResults.Text += "Calling AvoidMe()...\r\n";
				tc.AvoidMe();
				txtResults.Text += "AvoidMe() is finished.\r\n\r\n";
				txtResults.Text += "Calling TalkToTheChannel()...\r\n";
				tc.TalkToTheChannel();
				txtResults.Text += "TalkToTheChannel() is finished.\r\n\r\n";
				txtResults.Text += "Calling ToString()...\r\n";
				tc.ToString();
				txtResults.Text += "ToString() is finished.\r\n\r\n";
				txtResults.Text += "Calling ExceptionGeneration()...\r\n";
				tc.ExceptionGeneration();
				txtResults.Text += "ExceptionGeneration() is finished.\r\n\r\n";
			}
			catch(Exception ex) 
			{
				ErrorForm ef = new ErrorForm(ex);
				ef.ShowDialog(this);			
			}
		}
	}
}
