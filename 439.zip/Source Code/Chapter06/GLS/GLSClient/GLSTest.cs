using System;
using GetLetSet;

namespace GLSClient
{
	class GLSTestClient
	{
		[STAThread]
		static void Main(string[] args)
		{
			GLS gls = new GLSClass();
			gls.ThisIsTheDefault = 4;

			_GLSTest gt = new GLSTestClass();
			_GLS glRet = gt.get_MyGLS();
			Console.WriteLine("Before:  " + 
				glRet.ThisIsTheDefault.ToString());

			gt.let_MyGLS(ref gls);
			glRet = gt.get_MyGLS();
			Console.WriteLine("After:  " + 
				glRet.ThisIsTheDefault.ToString());
		}
	}
}
