using System;

namespace CSharpArrayAccess
{
	class Arrays
	{
		[STAThread]
		static void Main(string[] args)
		{
			char[] hello = {'H', 'e', 'l', 'l', 'o'};
			int[] values = {1, 2, 3, 4, 5};
			string[] guids = {"{BF37CF77-7673-4f67-BA21-9B65CF2D6DC6}", 
				"{E30578E3-B762-4bc6-88FD-371EE2AE10FF}", 
				"{2102A738-6D5B-4e77-85D7-ACC31F780125}"};
			NameValue[] namevalues = {new NameValue("This", 1), 
				new NameValue("That", 2), 
				new NameValue("Other", 3)};

			Console.WriteLine(hello[0].ToString());
			Console.WriteLine(values[0].ToString());
			Console.WriteLine(guids[0].ToString());
			Console.WriteLine(namevalues[0].Name);
			Console.WriteLine("Int:  " + CalcPower((int)10, (int)11).ToString());
			Console.WriteLine("Long:  " + CalcPower((long)10, (long)11).ToString());
		}

		static int CalcPower (int num,int power)
		{
			int result = 1;
			for(int i = 1;i<=power;i++)
			{
				result *= num;
			}
			return result;
		}

		static long CalcPower (long num, long power)
		{
			long result = 1;
			for(long i = 1;i<=power;i++)
			{
				result *= num;
			}
			return result;
		}

	}

	class NameValue
	{
		private string m_Name;
		private int m_Value;

		public NameValue(string Name, int Value)
		{
			this.m_Name = Name;
			this.m_Value = Value;
		}

		public string Name
		{
			get
			{
				return this.m_Name;
			}
			set
			{
				this.m_Name = value;
			}
		}

		public int Value
		{
			get
			{
				return this.m_Value;
			}
			set
			{
				this.m_Value = value;
			}
		}
		struct Point
		{
			public int x;
			public int y;
		}
		//using unsafe struct
		unsafe void MyUnsafeMethod()
		{
			Point point;
			point.x = 1;
			point.y = 2;
 
			Point* pPoint = &point;
			pPoint->x = 3;
			pPoint->y = 4;
		}
	}
}
