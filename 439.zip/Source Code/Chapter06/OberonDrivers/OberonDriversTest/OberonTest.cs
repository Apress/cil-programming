using System;
using DriveInterfaces;
using OberonDrivers;

namespace OberonDriversTest
{
	class OberonTest
	{
		[STAThread]
		static void Main(string[] args)
		{
			StockCarGolfer scg = new StockCarGolfer();
			IStockCarRacer ISCGStock = scg;
			Console.WriteLine("Calling Drive() on StockCarGolfer via IStockCarRacer = " +
				ISCGStock.Drive());
			IGolfer ISCGGolf = scg;
			Console.WriteLine("Calling Drive() on StockCarGolfer via IGolfer = " +
				ISCGGolf.Drive());
			Console.WriteLine("Calling GolfDrive() on StockCarGolfer = " +
				scg.GolfDrive());
			Console.WriteLine("Calling StockCarDrive() on StockCarGolfer = " +
				scg.StockCarDrive());

			BadDriver bd = new BadDriver();
			ISundayDriver IBadSunday = bd;
			Console.WriteLine("Calling Drive() on BadDriver via ISundayDriver = " +
				IBadSunday.Drive());
			IGolfer IBadGolf = bd;
			Console.WriteLine("Calling Drive() on BadDriver via IBadGolf = " +
				IBadGolf.Drive());
			Console.WriteLine("Calling GolferDrive() on BadDriver = " +
				bd.GolferDrive());
			Console.WriteLine("Calling SundayDrive() on BadDriver = " +
				bd.SundayDrive());
		}
	}
}
