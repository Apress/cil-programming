Option Strict On

Module ErrorResumeNext

    Sub Main()
        NoErrorHandling(3, 0)
        NewErrorHandling(3, 0)
        GotoErrorHandling(3, 0)
        ResumeNextErrorHandling(3, 0)
    End Sub

    Sub NewErrorHandling(ByVal X As Integer, ByVal Y As Integer)
        Try
            Dim Z As Integer
            Z = X \ Y
        Catch e As Exception

        End Try
    End Sub

    Sub GotoErrorHandling(ByVal X As Integer, ByVal Y As Integer)
        On Error GoTo ErrorHandler

        Dim Z As Integer
        Z = X \ Y

        Exit Sub

ErrorHandler:

    End Sub

    Sub ResumeNextErrorHandling(ByVal X As Integer, ByVal Y As Integer)
        On Error Resume Next
        Dim Z As Integer
        Z = X \ Y
    End Sub

    Sub NoErrorHandling(ByVal X As Integer, ByVal Y As Integer)
        Dim Z As Integer
        Z = X \ Y
    End Sub
End Module
