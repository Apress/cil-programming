Imports GuidGen

Public Class frmMain
    Inherits System.Windows.Forms.Form

    Private m_GuidGen As Generator

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        m_GuidGen = New Generator()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnGetGuid As System.Windows.Forms.Button
    Friend WithEvents lblGuid As System.Windows.Forms.Label
    Friend WithEvents btnStop As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnGetGuid = New System.Windows.Forms.Button()
        Me.lblGuid = New System.Windows.Forms.Label()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnGetGuid
        '
        Me.btnGetGuid.Location = New System.Drawing.Point(8, 8)
        Me.btnGetGuid.Name = "btnGetGuid"
        Me.btnGetGuid.Size = New System.Drawing.Size(96, 24)
        Me.btnGetGuid.TabIndex = 0
        Me.btnGetGuid.Text = "Get New Guid"
        '
        'lblGuid
        '
        Me.lblGuid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGuid.Location = New System.Drawing.Point(8, 48)
        Me.lblGuid.Name = "lblGuid"
        Me.lblGuid.Size = New System.Drawing.Size(224, 16)
        Me.lblGuid.TabIndex = 1
        Me.lblGuid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnStop
        '
        Me.btnStop.Location = New System.Drawing.Point(136, 8)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(96, 24)
        Me.btnStop.TabIndex = 2
        Me.btnStop.Text = "Stop"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(240, 77)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnStop, Me.lblGuid, Me.btnGetGuid})
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GuidGen Test"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnGetGuid_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetGuid.Click
        Me.lblGuid.Text = m_GuidGen.GetGuid().ToString()
    End Sub

    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        m_GuidGen.Stop()
    End Sub
End Class
