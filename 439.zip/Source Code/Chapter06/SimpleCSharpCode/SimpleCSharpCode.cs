using System;
using System.Reflection;
using System.Text;

namespace SimpleCSharpCode
{
	public class SimpleCode
	{
		static void Main()
		{
			SimpleCode sc = new SimpleCode();
			sc.TestForTypeName();
			sc.IncrementIntValue();
		}

		public bool TestForTypeName()
		{
			Type someType = this.GetType();
			String typeName = someType.Name;

			if(true == typeName.Equals("SimpleCode"))
			{
				int i;
				bool yes = true;
				return yes;
			}

			return false;
		}

		public int IncrementIntValue()
		{
			int i = 0;
			return i++;
		}
	}
}
