Module SimpleVBCode

    Public Class SimpleCode
        Public Shared Sub Main()
            Dim newThis As SimpleCode = New SimpleCode()
            newThis.TestForTypeName()
        End Sub

        Public Function TestForTypeName() As Boolean
            Dim someType As Type = Me.GetType()
            Dim typeName As String = someType.Name
            
            If True = typeName.Equals("SimpleCode") Then
                Dim i As Integer
                Dim yes As Boolean = True
                Return yes
            End If

            Return False
        End Function

        Public Function IncrementIntValue()
            Dim i As Integer = 0
            Return i + 1
        End Function
    End Class
End Module
