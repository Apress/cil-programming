using System;
using System.Reflection;

namespace OverrideAndOverload
{
	public class Chair {}

	public class ComfyChair : Chair {}

	public class Person
	{
		public string Sit(ComfyChair c)
		{
			MethodBase mb = MethodBase.GetCurrentMethod();
			return "You called " + 
				mb.DeclaringType.FullName + "\n" + 
				"\t" + mb.ToString() + "\n" + 
				"from type " + this.GetType().FullName + "\n";
		}
	}

	public class SpanishInquisitor : Person
	{
		public string Sit(Chair c)
		{
			MethodBase mb = MethodBase.GetCurrentMethod();
			return "You called " + 
				mb.DeclaringType.FullName + "\n" + 
				"\t" + mb.ToString() + "\n" + 
				"from type " + this.GetType().FullName + "\n";
		}
	}
}
