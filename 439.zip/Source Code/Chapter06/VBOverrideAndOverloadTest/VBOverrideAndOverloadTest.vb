Imports OverrideAndOverload

Module VBOverrideAndOverloadTest

    Sub Main()
        Dim c As Chair = New Chair()
        Dim cc As ComfyChair = New ComfyChair()
        Dim p As Person = New Person()
        Dim si As SpanishInquisitor = New SpanishInquisitor()

        Console.WriteLine(p.Sit(cc))
        Console.WriteLine(si.Sit(cc))
        Console.WriteLine(si.Sit(c))
    End Sub

End Module
