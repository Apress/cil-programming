using System;
using OverrideAndOverload;

namespace OverrideAndOverloadTest
{
	class OAOTest
	{
		[STAThread]
		static void Main(string[] args)
		{
			Chair c = new Chair();
			ComfyChair cc = new ComfyChair();
			Person p = new Person();
			SpanishInquisitor si = new SpanishInquisitor();

			Console.WriteLine(p.Sit(cc));
			Console.WriteLine(si.Sit(cc));
			Console.WriteLine(si.Sit(c));
		}
	}
}
