using System;
using DriveInterfaces;

namespace CSharpDrivers
{
	public class StockCarGolfer : IStockCarRacer, IGolfer
	{
		public StockCarGolfer()
		{
		}

		string IStockCarRacer.Drive()
		{
			return "Without rubbing you ain't got racing!";
		}

		string IGolfer.Drive()
		{
			return "350 yards right down the middle of the fairway...";
		}
	}

	public class BadDriver : ISundayDriver, IGolfer
	{
		public BadDriver()
		{
		}

		string ISundayDriver.Drive()
		{
			return this.Drive();
		}

		string IGolfer.Drive()
		{
			return this.Drive();
		}

		private string Drive()
		{
			return "I'm a bad driver no matter what I do.";
		}
	}
}
