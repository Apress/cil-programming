using System;

namespace DriveInterfaces
{
	public interface IGolfer
	{
		string Drive();
	}

	public interface IStockCarRacer
	{
		string Drive();
	}

	public interface ISundayDriver
	{
		string Drive();
	}
}
