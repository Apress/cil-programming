Imports DriveInterfaces

Namespace VBDrivers

    Public Class StockCarGolfer
        Implements IStockCarRacer, IGolfer

        Public Sub New()

        End Sub

        Private Function StockCarDrive() As String _
            Implements IStockCarRacer.Drive

            Return "Without rubbing you ain't got racing!"
        End Function

        Public Function GolfDrive() As String _
            Implements IGolfer.Drive

            Return "350 yards right down the middle of the fairway..."
        End Function
    End Class

    Public Class BadDriver
        Implements ISundayDriver, IGolfer

        Public Sub New()

        End Sub

        Public Function Drive() As String _
            Implements ISundayDriver.Drive, IGolfer.Drive

            Return "I'm a bad driver no matter what I do."
        End Function
    End Class

End Namespace