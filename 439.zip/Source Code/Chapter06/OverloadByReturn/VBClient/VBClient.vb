Module OBRTester

    '  VB . NET
    Sub Main()
        Dim gn As GetNumbers = New GetNumbers()
        Dim gnInt As Integer = gn.GiveMeANumber()
        Console.WriteLine(gnInt)
        Dim gnDouble As Double = gn.GiveMeANumber()
        Console.WriteLine(gnDouble)
    End Sub

End Module
