using System;

namespace CSharpClient
{
	class OBRTester
	{
		[STAThread]
		static void Main(string[] args)
		{
			GetNumbers gn = new GetNumbers();
			int gnInt = gn.GiveMeANumber();
			Console.WriteLine(gnInt);
			double gnDouble = gn.GiveMeANumber();
			Console.WriteLine(gnDouble);
		}
	}
}
