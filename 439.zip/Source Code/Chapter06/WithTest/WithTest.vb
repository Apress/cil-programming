Module WithTest

    Sub Main()
        Dim C As Atom = CreateAtom(Atoms.Carbon)
        WithPrintAtom(C)

        Dim Zn As Atom = CreateAtom(Atoms.Zinc)
        WithPrintAtom(Zn)
    End Sub

    Function CreateAtom(ByVal AtomType As Atoms) As Atom
        Select Case AtomType
            Case Atoms.Carbon
                Return CreateCarbonAtom()
            Case Atoms.Zinc
                Return CreateZincAtom()
        End Select
    End Function

    Private Function CreateCarbonAtom() As Atom
        Dim carbonNucleus As Nucleus = New Nucleus()
        ReDim carbonNucleus.Neutrons(5)
        ReDim carbonNucleus.Protrons(5)

        Dim carbon As Atom = New Atom()
        carbon.Name = "Carbon"
        carbon.Symbol = "C"
        carbon.Nucleus = carbonNucleus

        Return carbon
    End Function

    Private Function CreateZincAtom() As Atom
        Dim zincNucleus As Nucleus = New Nucleus()
        ReDim zincNucleus.Neutrons(37)
        ReDim zincNucleus.Protrons(29)

        Dim zinc As Atom = New Atom()
        zinc.Name = "Zinc"
        zinc.Symbol = "ZN"
        zinc.Nucleus = zincNucleus

        Return zinc
    End Function

    Function PrintAtom(ByVal TargetAtom As Atom)
        Console.WriteLine("Atom name is " & TargetAtom.Name)
        Console.WriteLine("Atom symbol is " & TargetAtom.Symbol)
        Console.WriteLine("Number of protons and electrons:  " & _
            TargetAtom.Electrons)
        Console.WriteLine("Number of neutrons:  " & TargetAtom.Nucleus.Neutrons.Length)
    End Function

    Function WithPrintAtom(ByVal TargetAtom As Atom)
        With TargetAtom
            Console.WriteLine("Atom name is " & .Name)
            With .Symbol
                Console.WriteLine("Atom symbol is " & .ToString)
            End With
            Console.WriteLine("Number of protons and electrons:  " & .Electrons)
            Console.WriteLine("Number of neutrons:  " & .Nucleus.Neutrons.Length)
        End With
    End Function

    Public Enum Atoms
        Carbon
        Zinc
    End Enum

    Public Class Atom
        Private m_Nucleus As Nucleus
        Private m_Name As String
        Private m_Symbol As String

        Public Property Nucleus() As Nucleus
            Get
                Return Me.m_Nucleus
            End Get
            Set(ByVal Value As Nucleus)
                Me.m_Nucleus = Value
            End Set
        End Property

        Public ReadOnly Property Electrons() As Integer
            Get
                Dim X As Integer = 0

                If Not Me.m_Nucleus.Protrons Is Nothing Then
                    X = Me.m_Nucleus.Protrons.Length
                End If

                Return X
            End Get
        End Property

        Public Property Name() As String
            Get
                Return Me.m_Name
            End Get
            Set(ByVal Value As String)
                Me.m_Name = Value
            End Set
        End Property

        Public Property Symbol() As String
            Get
                Return Me.m_Symbol
            End Get
            Set(ByVal Value As String)
                Me.m_Symbol = Value
            End Set
        End Property
    End Class

    Public Class Nucleus
        Private m_Protrons As Proton()
        Private m_Neutrons As Neutron()

        Public Property Protrons() As Proton()
            Get
                Return Me.m_Protrons
            End Get
            Set(ByVal Value As Proton())
                Me.m_Protrons = Value
            End Set
        End Property

        Public Property Neutrons() As Neutron()
            Get
                Return Me.m_Neutrons
            End Get
            Set(ByVal Value As Neutron())
                Me.m_Neutrons = Value
            End Set
        End Property
    End Class

    Public Class Proton
        Private m_Quark As Quark() = {Quark.u, Quark.u, Quark.d}

        Public ReadOnly Property Quarks() As Quark()
            Get
                Return Me.m_Quark
            End Get
        End Property
    End Class

    Public Class Neutron
        Private m_Quark As Quark() = {Quark.d, Quark.d, Quark.u}

        Public ReadOnly Property Quarks() As Quark()
            Get
                Return Me.m_Quark
            End Get
        End Property
    End Class

    Public Enum Quark
        u
        d
        s
        c
        t
        b
    End Enum
End Module
